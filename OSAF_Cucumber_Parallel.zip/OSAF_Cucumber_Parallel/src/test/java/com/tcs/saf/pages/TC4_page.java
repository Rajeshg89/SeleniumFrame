package com.tcs.saf.pages;
import org.bouncycastle.jcajce.provider.symmetric.ARC4.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC4_page 

{	
	//Windows properties
	private static final String Industries = ".//*[@id='mainnav']/li[3]/a";
	private static final String BankingFinancial = ".//*[@id='mainnav']/li[3]/div/ul/li[1]/a";
	private static final String VerifyBankingFinancial = ".//*[@id='overview']/h1";
	private static final String Government = ".//*[@id='industries_active']/div/ul/li[4]/a";
	private static final String VerifyGovernment = ".//*[@id='overview']/h1";
	private static final String Insurance = ".//*[@id='mainnav']/li[3]/div/ul/li[7]/a";
	private static final String VerifyInsurance = ".//*[@id='overview']/h1";
	private static final String Manufacturing = ".//*[@id='mainnav']/li[3]/div/ul/li[7]/a";
	private static final String VerifyManufacturing = ".//*[@id='overview']/h1";
	private static final String Telecom = ".//*[@id='mainnav']/li[3]/div/ul/li[13]/a";
	private static final String VerifyTelecom_Communication = ".//*[@id='overview']/h1";
	private static final String Utilities = ".//*[@id='mainnav']/li[3]/div/ul/li[15]/a";
	private static final String VerifyUtilities = ".//*[@id='overview']/h1";


	public void TC_4_1(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_BankingFinancial=BasePage.getLocator(BankingFinancial,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyBankingFinancial=BasePage.getLocator(VerifyBankingFinancial,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.maximizeWindow(driver);
			BasePage.delay(1000);
			
			BasePage.mouseOver(locator_Industries, driver);
			
			BasePage.click(locator_BankingFinancial, driver);
			BasePage.delay(1000);
			
			BasePage.isElementVisible(locator_VerifyBankingFinancial, driver);
			BasePage.delay(1000);
	}
	
	public void TC_4_2(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Government=BasePage.getLocator(Government,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyGovernment=BasePage.getLocator(VerifyGovernment,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Industries, driver);
		
		BasePage.click(locator_Government, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyGovernment, driver);
		BasePage.delay(1000);
	}
	
	public void TC_4_3(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Insurance=BasePage.getLocator(Insurance,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyInsurance=BasePage.getLocator(VerifyInsurance,  BY_TYPE.BY_XPATH,driver);
		
		
			BasePage.mouseOver(locator_Industries, driver);
			
			
			BasePage.click(locator_Insurance, driver);
			BasePage.delay(3000);
			
			
			BasePage.isElementVisible(locator_VerifyInsurance, driver);
			BasePage.delay(3000);
			
	}
	
	public void TC_4_4(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Manufacturing=BasePage.getLocator(Manufacturing,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyManufacturing=BasePage.getLocator(VerifyManufacturing,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Industries, driver);
		
		BasePage.click(locator_Manufacturing, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyManufacturing, driver);
		BasePage.delay(1000);
	}
	
	public void TC_4_5(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Telecom=BasePage.getLocator(Telecom,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyTelecom_Communication=BasePage.getLocator(VerifyTelecom_Communication,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Industries, driver);
		
		BasePage.click(locator_Telecom, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyTelecom_Communication, driver);
		BasePage.delay(1000);
	}
	public void TC_4_6(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Utilities=BasePage.getLocator(Utilities,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyUtilities=BasePage.getLocator(VerifyUtilities,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Industries, driver);
		
		BasePage.click(locator_Utilities, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyUtilities, driver);
		BasePage.delay(1000);
	}
}
