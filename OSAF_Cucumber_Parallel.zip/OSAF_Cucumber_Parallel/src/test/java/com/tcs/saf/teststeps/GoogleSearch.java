
package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.GoogleSearchPage;
import com.tcs.saf.test.GoogleSearchCucumber;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class GoogleSearch extends GoogleSearchCucumber {
	@Given("^user is on Google home page$")
	public void user_is_on_Google_search_page() throws Throwable {
		BasePage.launchPageURL("https://www.google.com",getDriver());			
		test.log(LogStatus.INFO, "Google home page launched");
	}

	@When("^enter \"([^\"]*)\" text into google search field$")
	public void user_enter_text_into_search_field(String Text) throws Throwable {
		//String value = getValue("Text to Enter");
		GoogleSearchPage.ProductSearch(Text,getDriver(),test);
	}

}
