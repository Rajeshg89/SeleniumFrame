

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_2_CucumberPage;
import com.tcs.saf.pages.TC_3_CucumberPage;
import com.tcs.saf.test.TC1Cucumber;
import com.tcs.saf.test.TC3Cucumber;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_3_Step extends TC3Cucumber {
	
	TC_3_CucumberPage page = new TC_3_CucumberPage();
	
	
	@Given("^user is on TCS homepage three$")
	public void user_is_on_TCS_homepage_three() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user click on the services tab control redirect to services page$")
	
	public void user_click_on_the_services_tab_control_redirect_to_services_page() throws Throwable {
		
		page.TC_3_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the control redirect to services page");
	
	}
	@And("^user verify the assurance service link is present under services$")
	
	public void user_verify_the_assurance_service_link_is_present_under_services() throws Throwable {
		
		page.TC_3_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the assurance service link is present under services");
	
	}
	@And("^user verify the platform solution link is present under services$")
	
	public void user_verify_the_platform_solution_link_is_present_under_services() throws Throwable {
	
		page.TC_3_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the platform solution link is present under services");
	
	}
		

}
