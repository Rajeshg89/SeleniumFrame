package com.tcs.saf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/*import atu.testng.reports.ATUReports;
 import atu.testng.reports.logging.LogAs;
 import atu.testng.selenium.reports.CaptureScreen;
 import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;*/
import com.tcs.saf.base.BasePage;

public class EriBankPage extends BasePage

{
	private static final String usernameTextField = "com.experitest.ExperiBank:id/usernameTextField";
	private static final String passwordTextField = "com.experitest.ExperiBank:id/passwordTextField";
	private static final String loginButton = "com.experitest.ExperiBank:id/loginButton";
	private static final String verification = "android:id/message";
	private static final String button3 = "android:id/button3";
	private static final String makePaymentButton = "com.experitest.ExperiBank:id/makePaymentButton";
	private static final String phoneTextField = "com.experitest.ExperiBank:id/phoneTextField";
	private static final String nameTextField = "com.experitest.ExperiBank:id/nameTextField";
	private static final String amountTextField = "com.experitest.ExperiBank:id/amountTextField";
	private static final String countryButton = "com.experitest.ExperiBank:id/countryButton";
	private static final String textUSA = "//android.widget.TextView[@text='USA']";
	private static final String countryTextField = "com.experitest.ExperiBank:id/countryTextField";
	private static final String sendPaymentButton = "com.experitest.ExperiBank:id/sendPaymentButton";
	private static final String AlertOk = "Yes";

	public void logIn(String username, String password, WebDriver driver) {

		By locator_username = getLocator(usernameTextField, BY_TYPE.BY_ID,
				driver);
		By locator_password = getLocator(passwordTextField, BY_TYPE.BY_ID,
				driver);
		By locator_login = getLocator(loginButton, BY_TYPE.BY_ID, driver);
		type(locator_username, username, driver);
		type(locator_password, password, driver);
		click(locator_login, driver);
		System.out.println("login sucessfully -------------- pass\n\n");

	}

	/*
	 * public void logInValidation(String username1, String password1 ) throws
	 * Exception{ By locator_username = getLocator(username1, BY_TYPE.BY_ID); By
	 * locator_password = getLocator(password1, BY_TYPE.BY_ID); By locator_login
	 * = getLocator(loginButton, BY_TYPE.BY_ID); By locator_msg =
	 * getLocator(verification, BY_TYPE.BY_ID); By locator_closeButton =
	 * getLocator(button3, BY_TYPE.BY_ID);
	 * 
	 * System.out.println("-------------login with wrong credentials \n");
	 * type(locator_username, usernameTextField); type(locator_password,
	 * passwordTextField); click(locator_login); String
	 * msg=getText(locator_msg);
	 * if(msg.equals("Invalid username or password!")){
	 * System.out.println("Invalid username or password!");
	 * System.out.println("we will close the error msg and then try the true login"
	 * ); Thread.sleep(10000);//sleep for 10S click(locator_closeButton);
	 * logIn(msg, msg); }
	 * System.out.println("login with wrong credentials -------------- failed \n\n"
	 * );
	 * 
	 * 
	 * 
	 * 
	 * 
	 * }
	 */

	public void makePayemernt(String phone, String nameText, String amountText,
			WebDriver driver) throws Exception {
		By locator_makePayment = getLocator(makePaymentButton, BY_TYPE.BY_ID,
				driver);
		By locator_phoneText = getLocator(phoneTextField, BY_TYPE.BY_ID, driver);
		By locator_nameText = getLocator(nameTextField, BY_TYPE.BY_ID, driver);
		By locator_amountText = getLocator(amountTextField, BY_TYPE.BY_ID,
				driver);
		By locator_countryButton = getLocator(countryButton, BY_TYPE.BY_ID,
				driver);
		By locator_textUSA = getLocator(textUSA, BY_TYPE.BY_XPATH, driver);
		By locator_countryText = getLocator(countryTextField, BY_TYPE.BY_ID,
				driver);
		By locator_sendPayment = getLocator(sendPaymentButton, BY_TYPE.BY_ID,
				driver);
		By locator_AlertOk = getLocator(AlertOk, BY_TYPE.BY_NAME, driver);
		click(locator_makePayment, driver);
		type(locator_phoneText, phone, driver);
		type(locator_nameText, nameText, driver);
		type(locator_amountText, amountText, driver);
		click(locator_countryButton, driver);
		click(locator_textUSA, driver);
		String country = getText(locator_countryText, driver);
		if (country.equals("USA")) {
			System.out
					.println("the country is validated lets make the payement");
			Thread.sleep(5000);
			click(locator_sendPayment, driver);
			System.out
					.println("payement done successfully  -------------- pass");

		}

		else {
			System.out.println("the country wasn't validated lets idk ");
			System.out.println("payement done   -------------- failed");

		}
		delay(5000);

		click(locator_AlertOk, driver);

	}

}
