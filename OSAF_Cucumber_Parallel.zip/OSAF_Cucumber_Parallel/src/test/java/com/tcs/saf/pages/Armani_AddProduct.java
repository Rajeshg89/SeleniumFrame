package com.tcs.saf.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class Armani_AddProduct

{	
	
	private static final String selectProductone ="//*[@id='elementsContainer']/div[2]/div[1]/ul/li[3]/a[2]/img";
	private static final String clickShoppingBag ="//*[@id='elm_1']";
	private static final String selectProducttwo ="//*[@id='elementsContainer']/div[2]/div[1]/ul/li[6]/a[2]/img";
	private static final String clickdropdown ="//*[@id='elm_4']";
	private static final String selectsize ="//*[@id='elm_4']/option[5]";
	private static final String cartIconVal ="//*[@id='topHeadUser']/ul/li[1]";
	private static final String proceedCheckout ="//*[@id='nextbottom']";
	private static final String ExpandToModify ="//*[@id='cartTitle']/div[2]/h1/a";
	private static final String shoppingbagTexts ="//*[@id='content']/div[2]/div[3]";
	private static final String removeProduct ="//*[@id='cartItems']/div[2]/div[3]/div[2]/a";
	private static final String shoppingbagText ="//*[@id='topHeadUser']/ul/li[1]";
	private static final String continueshopping ="//*[@id='checkoutNavigation_bottom']/div[2]";
	private static final String SideBarlogout ="//*[@id='topBar']/div/div/div[1]";
	private static final String logout ="//*[@id='siteNav']/div[3]/ul/li[4]";
	
	
	
	
	
/*	public void add_product_tocart(WebDriver driver) throws InterruptedException
	{
		
		//wait.until(ExpectedConditions.presenceOfElementLocated(locator_message));
		//String message=getText(locator_message);
		//Assert.assertTrue("Product add failed", message.contains("Product added"));
		By locator_select = BasePage.getLocator(selectproduct, BY_TYPE.BY_XPATH,driver);
		BasePage.delay(3000);
		BasePage.click(locator_select,driver);
			By locator_cart = BasePage.getLocator(addcart, BY_TYPE.BY_XPATH,driver);
			BasePage.delay(3000);
			By locator_message = BasePage.getLocator(successmessage, BY_TYPE.BY_XPATH,driver);
			BasePage.click(locator_cart,driver);
			//wait.until(ExpectedConditions.presenceOfElementLocated(locator_message));
			String message=BasePage.getText(locator_message,driver);
			Assert.assertTrue("Product add failed", message.contains("Product added"));
		
	}*/
	public void selectProduct1(WebDriver driver) throws InterruptedException{
		By loc_selectProductone = BasePage.getLocator(selectProductone, BY_TYPE.BY_XPATH,driver);
		BasePage.clickUsingJavascriptExecutor(loc_selectProductone,driver);
		BasePage.delay(2000);

		By loc_clickShoppingBag = BasePage.getLocator(clickShoppingBag, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_clickShoppingBag, "visibility", 20,driver);
		BasePage.click(loc_clickShoppingBag,driver);
	}	  

	public void selectProduct2(WebDriver driver) throws InterruptedException{
		By loc_selectProducttwo =BasePage. getLocator(selectProducttwo, BY_TYPE.BY_XPATH,driver);
		BasePage.clickUsingJavascriptExecutor(loc_selectProducttwo,driver);
		BasePage.delay(2000);

		By loc_clickdropdown = BasePage.getLocator(clickdropdown, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_clickdropdown, "visibility", 20,driver);
		BasePage.click(loc_clickdropdown,driver);
		BasePage.delay(2000);

		By loc_selectsize = BasePage.getLocator(selectsize, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_selectsize, "visibility", 20,driver);
		BasePage.click(loc_selectsize,driver);
		BasePage.delay(2000);

		By loc_clickShoppingBag = BasePage.getLocator(clickShoppingBag, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_clickShoppingBag, "visibility", 20,driver);
		BasePage.click(loc_clickShoppingBag,driver);
	
	}	
	public void retrieveCartContent(WebDriver driver) throws InterruptedException{
		By loc_cartIconVal = BasePage.getLocator(cartIconVal, BY_TYPE.BY_XPATH,driver);
		String cartval=BasePage.getText(loc_cartIconVal,driver);
		System.out.println("The items present in the cart is :"+cartval); 
		BasePage.delay(2000);
		BasePage.click(loc_cartIconVal,driver);
	}
	public void proceedCheckout(WebDriver driver) throws InterruptedException{
		By loc_proceedCheckout = BasePage.getLocator(proceedCheckout, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_proceedCheckout, "visibility", 20,driver);
		BasePage.click(loc_proceedCheckout,driver);
		BasePage.delay(3000);
	}
	public void shoppingbagText(WebDriver driver) throws InterruptedException{
		

		By loc_expandToModify = BasePage.getLocator(ExpandToModify, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_expandToModify, "visibility", 20,driver);
		BasePage.click(loc_expandToModify,driver);
		BasePage.delay(2000);
		By loc_shoppingbagTexts = BasePage.getLocator(shoppingbagTexts, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_shoppingbagTexts, "visibility", 20,driver);
		String bagvalue=BasePage.getText(loc_shoppingbagTexts,driver);
		System.out.println("The cart text is :"+bagvalue);
		BasePage.delay(2000);
	}
	public void removeProduct(WebDriver driver) throws InterruptedException{
		By loc_removeProduct = BasePage.getLocator(removeProduct, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_removeProduct, "visibility", 20,driver);
		BasePage.click(loc_removeProduct,driver);
		BasePage.delay(2000);
		By loc_shoppingbagText = BasePage.getLocator(shoppingbagText, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_shoppingbagText, "visibility", 20,driver);
		String bagval=BasePage.getText(loc_shoppingbagText,driver);
		System.out.println("The items present in the cart is :"+bagval); 
		
	}
	public void continueShopping(WebDriver driver) throws InterruptedException{
		By loc_continueshopping = BasePage.getLocator(continueshopping, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_continueshopping, "visibility", 20,driver);
		BasePage.click(loc_continueshopping,driver);
		BasePage.delay(2000);
	}
	public void clickLogout(WebDriver driver) throws InterruptedException{
		By loc_SideBarlogout = BasePage.getLocator(SideBarlogout, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_SideBarlogout, "visibility", 20,driver);
		BasePage.click(loc_SideBarlogout,driver);
		BasePage.delay(2000);
		
		By loc_logout = BasePage.getLocator(logout, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_logout, "visibility", 20,driver);
		BasePage.click(loc_logout,driver);
		BasePage.delay(2000);
	}
	

}
