

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_6_CucumberPage;
import com.tcs.saf.test.TC6Cucumber;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_6_Step extends TC6Cucumber {
	
	TC_6_CucumberPage page = new TC_6_CucumberPage();
	
	
	@Given("^user is on TCS homepage six$")
	public void user_is_on_TCS_homepage_six() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify page redirect to casestudies hovering Resources$")
	
	public void user_verify_page_redirect_to_casestudies_hovering_Resources() throws Throwable {
		
		page.TC_6_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to casestudies hovering Resources");
	
	}
	@And("^user verify page redirect to WhitePaper hovering Resources$")
	
	public void user_verify_page_redirect_to_WhitePaper_hovering_Resources() throws Throwable {
		
		page.TC_6_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to WhitePaper hovering Resources");
	
	}
	@And("^user verify page redirect to Newsletter hovering Resources$")
	
	public void user_verify_page_redirect_to_Newsletter_hovering_Resources() throws Throwable {
	
		page.TC_6_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to Newsletter hovering Resources");
	
	}
@And("^user verify page redirect to podcast hovering Resources$")
	
	public void user_verify_page_redirect_to_podcast_hovering_Resources() throws Throwable {
	
		page.TC_6_4(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to podcast hovering Resources");
	
	}
	


}
