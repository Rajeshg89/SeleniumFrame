
package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_1_CucumberPage;
import com.tcs.saf.test.TC1Cucumber;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_1_Step extends TC1Cucumber {
	
	TC_1_CucumberPage page = new TC_1_CucumberPage();
	
	
	@Given("^user is on TCS homepage one$")
	public void user_is_on_TCS_homepage_one() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify the link worldwide present$")
	
	public void user_verify_the_link_worldwide_present() throws Throwable {
		
		page.TC_1_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the link worldwide present");
	
	}
	@And("^user verify the link careers present$")
	
	public void user_verify_the_link_careers_present() throws Throwable {
	
		page.TC_1_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the link careers presen");
	
	}
	@And("^user verify the link investors present$")
	
	public void user_verify_the_link_investors_present() throws Throwable {
		
		page.TC_1_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the link investors present");
	
	}
	@And("^user verify the link contactus is redirecting to contactus page$")
	
	public void user_verify_the_link_contactus_is_redirecting_to_contactus_page () throws Throwable {
		
		page.TC_1_4(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the link contactus is redirecting to contactus pag");
	
	}
	@And("^user verify the share link present and enter \"([^\"]*)\"$")
	
	public void user_verify_the_share_present_and_enter(String Text) throws Throwable {
		
		page.TC_1_5(Text,getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the share link present");
	
	}
	

}
