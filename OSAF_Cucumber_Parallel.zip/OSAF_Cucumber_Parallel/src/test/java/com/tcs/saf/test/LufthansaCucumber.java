package com.tcs.saf.test;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import org.apache.commons.httpclient.auth.AuthenticationException;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BaseTest;
import com.tcs.saf.base.BrowserSetUp;
import com.tcs.saf.exceptions.DataSheetException;
import com.tcs.saf.exceptions.InvalidBrowserException;
import com.tcs.saf.teststeps.CucumberReport;
import com.tcs.saf.utilities.TestDataProvider;

import jxl.JXLException;
import jxl.read.biff.BiffException;
import jxl.write.biff.RowsExceededException;
		/**
		 * @author TCS Automation CoE
		 *
		 */

	public class LufthansaCucumber extends BaseTest{		
		public static ExtentReports report;
		public static ExtentTest test;	
		public static int testIteration = 1;
		
		public LufthansaCucumber()
		{
			this.testDataProvider = new TestDataProvider();
			getGridProperties();
			getGlobalProperties();
			
		}		
		public LufthansaCucumber(String testName,String browser, LinkedHashMap<String, String> mapDataSheet)
		{
			this.testName = testName;
			this.testDataProvider = new TestDataProvider();
			this.testBrowser = browser;
			super.mapDataSheet = mapDataSheet;
		}
		
		@Factory(dataProvider = "dataSheet")
		public Object[] testCreator(LinkedHashMap<String, String> mapDataSheet) {
			this.mapDataSheet = mapDataSheet;
			return new Object[] { new LufthansaCucumber(this.getClass().getSimpleName(),mapDataSheet.get("Browser"), mapDataSheet) };
		}
		@DataProvider(name="dataSheet")
		public  Object[][] getTestData() throws BiffException, IOException, InvalidBrowserException, DataSheetException{
			return testDataProvider.getTestDataFromExcel(externalSheetPath, this.getClass().getSimpleName());
		}		
		@BeforeMethod
		public void beforemethod() throws AuthenticationException, ClientHandlerException, IOException {
			setMapDataSheet(mapDataSheet);
			webDriver = BrowserSetUp.setMyBrowser(this.testBrowser,testName,mapDataSheet,execution_Format);
			reportpath = globalProperties.getString("report_path");
			report = new ExtentReports(reportpath+"LufthansaCucumber.html", false);
			test = TestReportGenerator(report,this.getClass().getSimpleName(),"Test Desciption");
		}	

		@Test
		public void Execute_test() throws MalformedURLException {	
			System.out.println("Iterating Data from row number: "+testIteration+" from the Test Data Sheet on Test :"+this.getClass().getSimpleName());
			String tags = mapDataSheet.get("Tags");	
			//BasePage.launchPageURL(getValue("URL"),getDriver());
			runCucumberTests(tags,this.getClass().getSimpleName());
			testIteration++;
		}
		
		@AfterMethod
		public void afterMethod(ITestResult testResult)
				throws SQLException, BiffException, IOException, RowsExceededException, JXLException {
			BrowserSetUp.terminateTest(testResult,this.testBrowser,test,report,getDriver());
		}


	}

