//
//package com.tcs.saf.test;
//import java.io.IOException;
//import java.util.LinkedHashMap;
//import jxl.read.biff.BiffException;
//import org.testng.Reporter;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Factory;
//import org.testng.annotations.Test;
//
//import com.tcs.saf.base.BaseTest;
//import com.tcs.saf.exceptions.DataSheetException;
//import com.tcs.saf.exceptions.InvalidBrowserException;
//
//public class Runner extends BaseTest
//{
//	
//	public Runner()
//	{
//
//		super();
//	
//	}
//	
//	public Runner(String testName,String browser, LinkedHashMap<String, String> mapDataSheet)
//	{
//
//				
//		super(testName,browser,mapDataSheet);
//		
//	}
//
//	   
//    @Factory(dataProvider = "dataSheet")
//	public Object[] testCreator(LinkedHashMap<String, String> mapDataSheet) 
//	{
//		
//		return new Object[] { new Runner(this.getClass().getSimpleName(),null,mapDataSheet) };
//
//	}
//
//
//	@DataProvider(name="dataSheet")
//	public  Object[][] getTestData() throws BiffException, IOException, InvalidBrowserException, DataSheetException
//	{
//		
//		return testDataProvider.getTestDataFromExcel(externalSheetPath, this.getClass().getSimpleName());
//
//	}
//    	
//@Test       
//	public void runserviceproject() throws RuntimeException
//	{	
//		try{			
//		//String prop ="-PCityFrom="+getValue("CityFrom")+" -PCityTo="+getValue("CityTo")+" -PFromUnit="+getValue("FromUnit")+" -PTemperature="+getValue("Temperature")+" -PToUnit="+getValue("ToUnit");
//		String prop ="-Pusername="+getValue("username")+" -Ppassword="+getValue("password")+"-Psessionid="+getValue("sessionid")+" -Psearch="+getValue("search")+" -Pbuy="+getValue("buy");
//		String path = " \"D:/Rahul/StommeAdvancedBuild/ServiceReport\" ";
//		String comm = " \"D:/Rahul/Shopping-soapui-projectfinaldemonegative.xml\" ";
//		System.out.println(prop);
//		Runtime.getRuntime().exec("D:/Rahul/SoapUI-5.2.0/bin/testrunner.bat -r -j -a -s Shopping "+prop+" -f"+path+comm);			
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//			Reporter.log(e.getMessage());
//			
//		}
//	}
////@Test
////	public void Soaptestcaserunner() throws IOException,Exception
////	{
////		try
////		{
////		String project="D:/BuildTest/StommeAdvancedBuild/src/test/resources/Sample-soapui-project.xml";
////		String[] prop ={"CityFrom="+getValue("CityFrom"),"CityTo="+getValue("CityTo"),"FromUnit="+getValue("FromUnit"),"Temperature="+getValue("Temperature"),"ToUnit="+getValue("ToUnit")};
////		runservice(project,prop,"SampleServices",null);
////		}
////		catch(Exception e)
////		{
////			
////		}
////	}
//}
