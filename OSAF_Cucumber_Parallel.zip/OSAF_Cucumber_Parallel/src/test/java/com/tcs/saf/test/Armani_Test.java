
package com.tcs.saf.test;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.pages.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import jxl.JXLException;
import jxl.read.biff.BiffException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.httpclient.auth.AuthenticationException;
//import org.sikuli.script.FindFailed;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BaseTest;
import com.tcs.saf.base.BrowserSetUp;
import com.tcs.saf.exceptions.DataSheetException;
import com.tcs.saf.exceptions.InvalidBrowserException;
import com.tcs.saf.utilities.TestDataProvider;

public class Armani_Test extends BaseTest {
	public static ExtentReports report;
	public static ExtentTest test;		
	public Armani_Test()
	{
		this.testDataProvider = new TestDataProvider();
		getGridProperties();
		getGlobalProperties();		
	}
	
	public Armani_Test(String testName,String browser, LinkedHashMap<String, String> mapDataSheet)
	{
		this.testName = testName;
		this.testDataProvider = new TestDataProvider();
		this.testBrowser = browser;
		this.mapDataSheet = mapDataSheet;
	}

	@Factory(dataProvider = "dataSheet")
	public Object[] testCreator(LinkedHashMap<String, String> mapDataSheet) {
		return new Object[] { new Armani_Test(this.getClass().getSimpleName(),mapDataSheet.get("Browser"), mapDataSheet) };
	}


	@DataProvider(name="dataSheet")
	public  Object[][] getTestData() throws BiffException, IOException, InvalidBrowserException, DataSheetException{
		return testDataProvider.getTestDataFromExcel(externalSheetPath, this.getClass().getSimpleName());
	}
	@BeforeMethod
	public void beforemethod() throws AuthenticationException, ClientHandlerException, IOException {	
		webDriver = BrowserSetUp.setMyBrowser(this.testBrowser,testName,mapDataSheet,execution_Format);
		reportpath = globalProperties.getString("report_path");
		report = new ExtentReports(reportpath+"FlipkartTest.html", false);
		test = TestReportGenerator(report,this.getClass().getSimpleName(),"Test Desciption");
	}	

	@Test
	public void sampleTest() throws InterruptedException, ClientHandlerException, IOException {				
		Reporter.log("Execution of test case using : "+ mapDataSheet.get("TestCaseName"));	
		BasePage.launchPageURL(mapDataSheet.get("URL"),getDriver());
		test.log(LogStatus.INFO, "Armani home page launched");
        Reporter.log("Launched the Application Under Test");
        
        //Enter Armani home Page
        ArmaniHome_Page home=new ArmaniHome_Page();
     
		home.clickLoginlink(getDriver());
		home.selectTitle(getDriver());
		home.enterName(mapDataSheet.get("FirstName"), mapDataSheet.get("LastName"),getDriver());
		home.enterEmail(getDriver());
		home.enterPassword(getDriver());
		
		//Search for Products
		Armani_SearchProduct search=new Armani_SearchProduct();
		search.clicksearch( mapDataSheet.get("Product1"),getDriver());
		test.log(LogStatus.INFO, "Product is added to cart ");
		
		//Add product
		Armani_AddProduct add=new Armani_AddProduct();
		
		add.selectProduct1(getDriver());
		search.clicksearch(mapDataSheet.get("Product2"),getDriver());
		add.selectProduct2(getDriver());
		add.retrieveCartContent(getDriver());
		add.proceedCheckout(getDriver());
		add.shoppingbagText(getDriver());
		add.removeProduct(getDriver());
		add.continueShopping(getDriver());
		add.clickLogout(getDriver());
		
		}
	@AfterMethod
	public void afterMethod(ITestResult testResult)
			throws SQLException, BiffException, IOException, RowsExceededException, JXLException {
		System.out.println("entering after");
		BrowserSetUp.terminateTest(testResult,this.testBrowser,test,report,getDriver());
	}
}	
