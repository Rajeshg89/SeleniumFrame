

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_4_CucumberPage;
import com.tcs.saf.test.TC1Cucumber;
import com.tcs.saf.test.TC4Cucumber;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_4_Step extends TC4Cucumber {
	
	TC_4_CucumberPage page = new TC_4_CucumberPage();
	
	
	@Given("^user is on TCS homepage four$")
	public void user_is_on_TCS_homepage_four() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify page redirect to BankingFinancial hovering industries$")
	
	public void user_verify_page_redirect_to_BankingFinancial_hovering_industries() throws Throwable {
		
		page.TC_4_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to BankingFinancial hovering industries");
	
	}
	@And("^user verify page redirect to Government hovering industries$")
	
	public void user_verify_page_redirect_to_Government_hovering_industries() throws Throwable {
		
		page.TC_4_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to Government hovering industries");
	
	}
	@And("^user verify page redirect to Insurance hovering industries$")
	
	public void user_verify_page_redirect_to_Insurance_hovering_industries() throws Throwable {
	
		page.TC_4_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to Insurance hovering industries");
	
	}
@And("^user verify page redirect to Manufacturing hovering industries$")
	
	public void user_verify_page_redirect_to_Manufacturing_hovering_industries() throws Throwable {
	
		page.TC_4_4(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to Manufacturing hovering industries");
	
	}
@And("^user verify page redirect to Telecom hovering industries$")

public void user_verify_page_redirect_to_Telecom_hovering_industries() throws Throwable {

	page.TC_4_5(getDriver(),test);
	test.log(LogStatus.INFO, "successfuly verified the page redirect to Telecom hovering industries");

}
@And("^user verify page redirect to Utilities hovering industries$")

public void user_verify_page_redirect_to_Utilities_hovering_industries() throws Throwable {

	page.TC_4_6(getDriver(),test);
	test.log(LogStatus.INFO, "successfuly verified the page redirect to Utilities hovering industries");

}
	


}
