package com.tcs.saf.teststeps;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.ResourceBundle;

import jxl.JXLException;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.biff.JxlWriteException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
//import java.util.List;
import org.testng.Reporter;





import com.tcs.saf.base.BaseTest;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;


/**
 * This class is for defining the common methods that would be used for Cucumber scenario execution

 *
 */
public class CucumberReport extends BaseTest {
	Scenario scenario; 
	public static ResourceBundle globalProperties;
	public static String reportscreenshotpath;
	WebDriver driver;

@Before
public void setUp(Scenario scenario)
{
	this.scenario=scenario;
}
	@After
	public void teardown () throws JxlWriteException, BiffException, IOException, JXLException {

		//This status variable will fetch the status of the cucumber scenario and if the status is failed
		//screenshot will be taken.Screen shot will be saved in the name of the scenario
		String status=scenario.getStatus(); 
		System.out.println("Scenario name:"+scenario.getName());
		System.out.println("Scenario status:"+scenario.getStatus());

		if(status.equalsIgnoreCase("failed"))
		{
			globalProperties = ResourceBundle.getBundle("global");
			reportscreenshotpath = globalProperties.getString("reportscreenshot_path");
			String screenshotName=scenario.getName();
			try {
				TakesScreenshot ts = (TakesScreenshot) getDriver();
				File source = ts.getScreenshotAs(OutputType.FILE);
				String Dest = reportscreenshotpath + screenshotName + System.nanoTime() + ".png";
				File Destination = new File(Dest);
				FileUtils.copyFile(source, Destination);
				System.out.println("Screenshot taken");

			} catch (Exception e) {
				System.out.println("Exception while taking screenshot " + e.getMessage());

			}	
		}
	}





}