package com.tcs.saf.pages;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class ArmaniHome_Page 

{	
	private static final String login ="//*[@id='topHeadUser']/ul/li[2]";
	private static final String register ="//*[@id='addToWrapper']/a/p";
	private static final String titleOption ="gender";
	private static final String titleasMr ="//*[@id='gender']/option[2]"; 
	private static final String fName ="//*[@id='name']";
	private static final String lName ="//*[@id='surname']";
	private static final String email ="//*[@id='email']";
	private static final String confirmEmail ="email2";
	private static final String password ="//*[@id='passwordReg']";
	private static final String confirmPassword ="//*[@id='passwordReg2']";
	private static final String clickSubmit ="//*[@id='signinSubmit']";
	
   
	
	
/*	public void search_product(String product_name,WebDriver driver) throws InterruptedException
	{
		By locator_search = BasePage.getLocator(searchinput, BY_TYPE.BY_XPATH,driver);
			//By locator_sbutton = BasePage.getLocator(searchbutton, BY_TYPE.BY_XPATH,driver);
			By locator_item = BasePage.getLocator(item, BY_TYPE.BY_XPATH,driver);
			BasePage.type(locator_search, product_name,driver);
			//BasePage.click(locator_sbutton,driver);
			driver.findElement(By.xpath(".//*[@name='q']")).sendKeys(Keys.ENTER);
			BasePage.delay(10000);
			List<WebElement> searchResults=driver.findElements(By.xpath("((//div[@data-aid='searchresults_products-container']/div[contains(.,'')])[3]/div[contains(.,'')])[1]/div[contains(@data-aid,'product_list_unit')]"));
			int sizeSearchResults=searchResults.size();
			Assert.assertTrue("Search results not found", sizeSearchResults>0);
			BasePage.click(locator_item,driver);
			BasePage.delay(5000);
		
			
	}*/
	public void clickLoginlink(WebDriver driver) throws InterruptedException{
		BasePage.deleteAllCookie(driver);
		By loc_login = BasePage.getLocator(login, BY_TYPE.BY_XPATH,driver);
		BasePage.click(loc_login,driver);

		By loc_register = BasePage.getLocator(register, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_register, "visibility", 20,driver);
		BasePage.click(loc_register,driver);	
	}
	public void selectTitle(WebDriver driver) throws InterruptedException{
		//Select title from dropdown
		By loc_title = BasePage.getLocator(titleOption, BY_TYPE.BY_ID,driver);
		BasePage.addExplicitWait(loc_title, "visibility", 30,driver);
		BasePage.click(loc_title,driver);
		BasePage.delay(3000);
      
        By loc_titleMr = BasePage.getLocator(titleasMr, BY_TYPE.BY_XPATH,driver);
        BasePage.addExplicitWait(loc_titleMr, "visibility", 30,driver);
        BasePage.click(loc_titleMr,driver);
        BasePage.delay(3000);
		
	}
	public void enterName(String firstName,String lastName,WebDriver driver) throws InterruptedException{
		
		 
		   
		By loc_fName = BasePage.getLocator(fName, BY_TYPE.BY_XPATH,driver);
		BasePage.scrollToElementUsingJavascriptExecutor(loc_fName,driver);
		BasePage.addExplicitWait(loc_fName, "visibility", 20,driver);
		BasePage.type(loc_fName, firstName,driver);
		By loc_lName = BasePage.getLocator(lName, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_lName, "visibility", 20,driver);
		BasePage.type(loc_lName, lastName,driver);
	}
		
		
	public void enterEmail(WebDriver driver) throws InterruptedException{
		//Generate Random EmailAddress
		int ran;
		ran = 100 + (int)(Math.random() * ((10000 - 100) + 1));

		By loc_email = BasePage.getLocator(email, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_email, "visibility", 20,driver);
		Boolean enabledEle=BasePage.isElementEnabled(loc_email,driver);
		System.out.println("The element is :"+enabledEle);
		BasePage.type(loc_email, "Danny" + ran + "@yahoo.com",driver);
		

		String emailText=driver.findElement(By.xpath("//*[@id='email']")).getAttribute("value");
		System.out.println("The email is "+emailText);

		By loc_confrmemail = BasePage.getLocator(confirmEmail, BY_TYPE.BY_NAME,driver);
		BasePage.addExplicitWait(loc_confrmemail, "visibility", 20,driver);
		BasePage.type(loc_confrmemail, emailText,driver);
		Thread.sleep(1000);

	}
	public void enterPassword(WebDriver driver) throws InterruptedException{
		By loc_passwrd = BasePage.getLocator(password, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_passwrd, "visibility", 20,driver);
		BasePage.type(loc_passwrd, "Newyear@2017",driver);
		Thread.sleep(1000);

		String passwordText=driver.findElement(By.xpath("//*[@id='passwordReg']")).getAttribute("value");
		System.out.println("The email is "+passwordText);
		By loc_confPasswrd = BasePage.getLocator(confirmPassword, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_confPasswrd, "visibility", 20,driver);
		BasePage.type(loc_confPasswrd,passwordText,driver);
		Thread.sleep(1000);

		By loc_submit = BasePage.getLocator(clickSubmit, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_submit, "visibility", 20,driver);
		BasePage.click(loc_submit,driver);
		Thread.sleep(1000);

	}	    

	
}
