package com.tcs.saf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class TC7_Page 

{	
	
	private static final String AboutTCS=".//*[@id='mainnav']/li[5]/a";
	private static final String EcperienceCertainity=".//*[@id='mainnav']/li[5]/div/ul/li[1]/a";
	private static final String VerifyEcperienceCertainity=".//*[@id='overview']/h1";
	private static final String worldwide=".//*[@id='globalnav']/li[2]/a";
	private static final String worldwide_verification=".//*[@id='g_intro']/div/h1";
	private static final String  northamerica=".//*[@id='ww_column_1']/ul/li[1]/a";
	private static final String canada=".//*[@id='na_links']/li[1]/a";
	private static final String	sharelink=".//*[@id='main']/div[2]/div[2]/ul/li[1]/a";

	private static final String RSSFeed=".//*[@id='main']/div[2]/div[2]/ul/li[2]/a";
	private static final String printpage=".//*[@id='main']/div[2]/div[2]/ul/li[3]/a";
	private static final String emailthis=".//*[@id='main']/div[2]/div[2]/ul/li[4]/a";


	
	public void TC_7_1(WebDriver driver) throws InterruptedException
	{
		    By locator_AboutTCS = BasePage.getLocator(AboutTCS, BY_TYPE.BY_XPATH,driver);
		    BasePage.mouseOver(locator_AboutTCS, driver);
		   
		    
			By locator_EcperienceCertainity = BasePage.getLocator(EcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.click(locator_EcperienceCertainity, driver);
			BasePage.delay(1000);
			
			By locator_VerifyEcperienceCertainity = BasePage.getLocator(VerifyEcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_VerifyEcperienceCertainity, driver);
			
		/*	By locator_continue1 = BasePage.getLocator(continue1, BY_TYPE.BY_XPATH,driver);
		    BasePage.click(locator_continue1,driver);*/
				
			
	}
	public void TC_7_2(WebDriver driver) throws InterruptedException
	{
		    By locator_AboutTCS = BasePage.getLocator(AboutTCS, BY_TYPE.BY_XPATH,driver);
		    BasePage.mouseOver(locator_AboutTCS, driver);

			By locator_EcperienceCertainity = BasePage.getLocator(EcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.click(locator_EcperienceCertainity, driver);
			BasePage.delay(1000);
			
			By locator_VerifyEcperienceCertainity = BasePage.getLocator(VerifyEcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_VerifyEcperienceCertainity, driver);
			
		    By locator_worldwide = BasePage.getLocator(worldwide, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_worldwide, driver);
		    BasePage.click(locator_worldwide, driver);
		    BasePage.delay(1000);
		   
		    
			By locator_worldwideverification = BasePage.getLocator(worldwide_verification, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_worldwideverification, driver);
			
			By locator_northamerica = BasePage.getLocator(northamerica, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_northamerica, driver);
			
			By locator_canada = BasePage.getLocator(canada, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_canada, driver);
				
			
	}
	public void TC_7_3(WebDriver driver) throws InterruptedException
	{
		    By locator_AboutTCS = BasePage.getLocator(AboutTCS, BY_TYPE.BY_XPATH,driver);
		    BasePage.mouseOver(locator_AboutTCS, driver);
		       
			By locator_EcperienceCertainity = BasePage.getLocator(EcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.click(locator_EcperienceCertainity, driver);
			BasePage.delay(1000);
			
			By locator_VerifyEcperienceCertainity = BasePage.getLocator(VerifyEcperienceCertainity, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_VerifyEcperienceCertainity, driver);
			
		    By locator_worldwide = BasePage.getLocator(sharelink, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_worldwide, driver);

			By locator_worldwideverification = BasePage.getLocator(RSSFeed, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_worldwideverification, driver);
			
			By locator_northamerica = BasePage.getLocator(printpage, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_northamerica, driver);
			
			By locator_canada = BasePage.getLocator(emailthis, BY_TYPE.BY_XPATH,driver);
			BasePage.isElementVisible(locator_canada, driver);
				
			
	}



	
}
