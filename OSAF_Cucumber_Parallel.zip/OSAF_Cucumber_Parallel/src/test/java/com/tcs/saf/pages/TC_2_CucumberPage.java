
package com.tcs.saf.pages;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;

import com.relevantcodes.extentreports.ExtentTest;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC_2_CucumberPage 

{	
	/******************** Locators for Service components *****************/
	
	private static final String services = ".//*[@id='footer_left']/ul/li[1]/strong/a";
	private static final String Sub_AssuranceServices = ".//*[@id='footer_left']/ul/li[1]/a[1]";
	private static final String Sub_BiPerfrmance = ".//*[@id='footer_left']/ul/li[1]/a[2]";
	private static final String Sub_BusinessProcess = ".//*[@id='footer_left']/ul/li[1]/a[3]";
	private static final String Sub_consulting = ".//*[@id='footer_left']/ul/li[1]/a[4]";
	private static final String Sub_digitalEnterprise = ".//*[@id='footer_left']/ul/li[1]/a[5]";
	private static final String Sub_Eco_sustainability = ".//*[@id='footer_left']/ul/li[1]/a[6]";
	private static final String Sub_EngineeringIndustrial = ".//*[@id='footer_left']/ul/li[1]/a[7]";
	private static final String Sub_EnterpriseSecurityRisk = ".//*[@id='footer_left']/ul/li[1]/a[8]";
	private static final String Sub_EnterpriseSolution = ".//*[@id='footer_left']/ul/li[1]/a[9]";
	private static final String Sub_iON = ".//*[@id='footer_left']/ul/li[1]/a[10]";
	private static final String Sub_ItInfra = ".//*[@id='footer_left']/ul/li[1]/a[11]";
	private static final String Sub_ItServices = ".//*[@id='footer_left']/ul/li[1]/a[12]";
	private static final String Sub_PlatformSolutions = ".//*[@id='footer_left']/ul/li[1]/a[13]";
	
	/******************** Locators for Industries components *****************/
	
	private static final String Industries = ".//*[@id='footer_left']/ul/li[2]/strong/a";
	private static final String Sub_BankingFinancial = ".//*[@id='footer_left']/ul/li[2]/a[1]";
	private static final String Sub_ConsumerPackaged = ".//*[@id='footer_left']/ul/li[2]/a[2]";
	private static final String Sub_EnergyOil = ".//*[@id='footer_left']/ul/li[2]/a[3]";
	private static final String Sub_Government = ".//*[@id='footer_left']/ul/li[2]/a[4]";
	private static final String Sub_Healthcare = ".//*[@id='footer_left']/ul/li[2]/a[5]";
	private static final String Sub_HighTech = ".//*[@id='footer_left']/ul/li[2]/a[6]";
	private static final String Sub_Insurance = ".//*[@id='footer_left']/ul/li[2]/a[7]";
	private static final String Sub_LifeScience = ".//*[@id='footer_left']/ul/li[2]/a[8]";
	private static final String Sub_Manufacturing = ".//*[@id='footer_left']/ul/li[2]/a[9]";
	private static final String Sub_MediaInformation = ".//*[@id='footer_left']/ul/li[2]/a[10]";
	private static final String Sub_Resource = ".//*[@id='footer_left']/ul/li[2]/a[11]";
	private static final String Sub_Retail = ".//*[@id='footer_left']/ul/li[2]/a[12]";
	private static final String Sub_Telecom = ".//*[@id='footer_left']/ul/li[2]/a[13]";
	private static final String Sub_TravelTransport = ".//*[@id='footer_left']/ul/li[2]/a[14]";
	private static final String Sub_Utilities = ".//*[@id='footer_left']/ul/li[2]/a[15]";
	
/******************** Locators for Software components *****************/
	
	private static final String Software = ".//*[@id='footer_left']/ul/li[3]/strong/a";
	private static final String Sub_DigitalSoftware = ".//*[@id='footer_left']/ul/li[3]/a[1]";
	private static final String Sub_idnio = ".//*[@id='footer_left']/ul/li[3]/a[2]";
	private static final String Sub_TCSBaNCS = ".//*[@id='footer_left']/ul/li[3]/a[3]";
	private static final String Sub_TCSCloudPlus = ".//*[@id='footer_left']/ul/li[3]/a[4]";
	private static final String Sub_TCSMastercraft = ".//*[@id='footer_left']/ul/li[3]/a[5]";
	private static final String Sub_TCSTechProducts = ".//*[@id='footer_left']/ul/li[3]/a[6]";
	
/******************** Locators for Software components *****************/
	
	private static final String connectWithTcs = ".//*[@id='withsocial']/li";
	private static final String contactus = ".//*[@id='footerothers']/li[1]/a";
	private static final String disclaimer = ".//*[@id='footerothers']/li[2]/a";
	private static final String privacyPolicy = ".//*[@id='footerothers']/li[3]/a";
	private static final String safeHarbor = ".//*[@id='footerothers']/li[4]/a";
	private static final String sitemap = ".//*[@id='footerothers']/li[5]/a";
	
/******************** Locators for copyright components *****************/
	
	private static final String CopyrightLink = ".//*[@id='newfooter_bottom']/ul/li[1]";
	
	
	public void TC_2_1(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{
		/******************** Locators for Service components *****************/
		
		By locator_services=BasePage.getLocator(services,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_AssuranceServices=BasePage.getLocator(Sub_AssuranceServices,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_BiPerfrmance=BasePage.getLocator(Sub_BiPerfrmance,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_BusinessProcess=BasePage.getLocator(Sub_BusinessProcess,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_consulting=BasePage.getLocator(Sub_consulting,  BY_TYPE.BY_XPATH,driver);   
		By locator_Sub_digitalEnterprise=BasePage.getLocator(Sub_digitalEnterprise,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Eco_sustainability=BasePage.getLocator(Sub_Eco_sustainability,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_EngineeringIndustrial=BasePage.getLocator(Sub_EngineeringIndustrial,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_EnterpriseSecurityRisk=BasePage.getLocator(Sub_EnterpriseSecurityRisk,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_EnterpriseSolution=BasePage.getLocator(Sub_EnterpriseSolution,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_iON=BasePage.getLocator(Sub_iON,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_ItInfra=BasePage.getLocator(Sub_ItInfra,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_ItServices=BasePage.getLocator(Sub_ItServices,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_PlatformSolutions=BasePage.getLocator(Sub_PlatformSolutions,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.maximizeWindow(driver);
		BasePage.delay(1000);
			
		/******************** Service components verification *****************/
			
			BasePage.isElementVisible(locator_services, driver);
		    
		    BasePage.isElementVisible(locator_Sub_AssuranceServices, driver);
		    
		    BasePage.isElementVisible(locator_Sub_BiPerfrmance, driver);
		    
		    BasePage.isElementVisible(locator_Sub_BusinessProcess, driver);
		    
		    BasePage.isElementVisible(locator_Sub_consulting, driver);
		    
		    BasePage.isElementVisible(locator_Sub_digitalEnterprise, driver);
		    
		    BasePage.isElementVisible(locator_Sub_Eco_sustainability, driver);
		    
		    BasePage.isElementVisible(locator_Sub_EngineeringIndustrial, driver);
		    
		    BasePage.isElementVisible(locator_Sub_EnterpriseSecurityRisk, driver);
		    
		    BasePage.isElementVisible(locator_Sub_EnterpriseSolution, driver);
		    
		    BasePage.isElementVisible(locator_Sub_iON, driver);
		    
		    BasePage.isElementVisible(locator_Sub_ItInfra, driver);
		    
		    BasePage.isElementVisible(locator_Sub_ItServices, driver);
		    
		    BasePage.isElementVisible(locator_Sub_PlatformSolutions, driver);
		    
		   
	}
	
	public void TC_2_2(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{
		/******************** Locators for Industries components *****************/
		By locator_Industries=BasePage.getLocator(Industries,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_BankingFinancial=BasePage.getLocator(Sub_BankingFinancial,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_ConsumerPackaged=BasePage.getLocator(Sub_ConsumerPackaged,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_EnergyOil=BasePage.getLocator(Sub_EnergyOil,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Government=BasePage.getLocator(Sub_Government,  BY_TYPE.BY_XPATH,driver);   
		By locator_Sub_Healthcare=BasePage.getLocator(Sub_Healthcare,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_HighTech=BasePage.getLocator(Sub_HighTech,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Insurance=BasePage.getLocator(Sub_Insurance,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_LifeScience=BasePage.getLocator(Sub_LifeScience,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Manufacturing=BasePage.getLocator(Sub_Manufacturing,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_MediaInformation=BasePage.getLocator(Sub_MediaInformation,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Resource=BasePage.getLocator(Sub_Resource,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Retail=BasePage.getLocator(Sub_Retail,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Telecom=BasePage.getLocator(Sub_Telecom,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_TravelTransport=BasePage.getLocator(Sub_TravelTransport,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_Utilities=BasePage.getLocator(Sub_Utilities,  BY_TYPE.BY_XPATH,driver);
		
		/******************** Industries components verification *****************/
		
	    BasePage.isElementVisible(locator_Industries, driver);
	    
	    BasePage.isElementVisible(locator_Sub_BankingFinancial, driver);
	    
	    BasePage.isElementVisible(locator_Sub_ConsumerPackaged, driver);
	    
	    BasePage.isElementVisible(locator_Sub_EnergyOil, driver);
	    
	    BasePage.isElementVisible(locator_Sub_HighTech, driver);
	    
	    BasePage.isElementVisible(locator_Sub_Insurance, driver);
	    
	    BasePage.isElementVisible(locator_Sub_MediaInformation, driver);
	    
	    BasePage.isElementVisible(locator_Sub_Retail, driver);
	    
	    BasePage.isElementVisible(locator_Sub_Telecom, driver);
	    
	    BasePage.isElementVisible(locator_Sub_TravelTransport, driver);
	    
	    BasePage.isElementVisible(locator_Sub_Utilities, driver);
	   
	    BasePage.isElementVisible(locator_Sub_Government, driver);
	    BasePage.isElementVisible(locator_Sub_Healthcare, driver);
	    BasePage.isElementVisible(locator_Sub_LifeScience, driver); 
	    BasePage.isElementVisible(locator_Sub_Manufacturing, driver);
	    BasePage.isElementVisible(locator_Sub_Resource, driver);
	}
	
	public void TC_2_3(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{

		/******************** Locators for Sotware components *****************/
		By locator_Software=BasePage.getLocator(Software,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_DigitalSoftware=BasePage.getLocator(Sub_DigitalSoftware,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_idnio=BasePage.getLocator(Sub_idnio,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_TCSBaNCS=BasePage.getLocator(Sub_TCSBaNCS,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_TCSCloudPlus=BasePage.getLocator(Sub_TCSCloudPlus,  BY_TYPE.BY_XPATH,driver);   
		By locator_Sub_TCSMastercraft=BasePage.getLocator(Sub_TCSMastercraft,  BY_TYPE.BY_XPATH,driver);
		By locator_Sub_TCSTechProducts=BasePage.getLocator(Sub_TCSTechProducts,  BY_TYPE.BY_XPATH,driver);
		
		/******************** Software components verification *****************/
		
		BasePage.isElementVisible(locator_Software, driver);
	    
	    BasePage.isElementVisible(locator_Sub_DigitalSoftware, driver);
	    
	    BasePage.isElementVisible(locator_Sub_idnio, driver);
	    
	    BasePage.isElementVisible(locator_Sub_TCSBaNCS, driver);
	    
	    BasePage.isElementVisible(locator_Sub_TCSCloudPlus, driver);
	    
	    BasePage.isElementVisible(locator_Sub_TCSMastercraft, driver);
	    
	    BasePage.isElementVisible(locator_Sub_TCSTechProducts, driver);
	}
	
	public void TC_2_4(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{
		/******************** Locators for Connect With Us components *****************/
		By locator_connectWithTcs=BasePage.getLocator(connectWithTcs,  BY_TYPE.BY_XPATH,driver);
		By locator_contactus=BasePage.getLocator(contactus,  BY_TYPE.BY_XPATH,driver);
		By locator_disclaimer=BasePage.getLocator(disclaimer,  BY_TYPE.BY_XPATH,driver);
		By locator_privacyPolicy=BasePage.getLocator(privacyPolicy,  BY_TYPE.BY_XPATH,driver);
		By locator_safeHarbor=BasePage.getLocator(safeHarbor,  BY_TYPE.BY_XPATH,driver);   
		By locator_sitemap=BasePage.getLocator(sitemap,  BY_TYPE.BY_XPATH,driver);
		
		/******************** Contact Us components verification *****************/
		
		BasePage.isElementVisible(locator_connectWithTcs, driver);
	    
	    BasePage.isElementVisible(locator_contactus, driver);
	    
	    BasePage.isElementVisible(locator_disclaimer, driver);
	    
	    BasePage.isElementVisible(locator_privacyPolicy, driver);
	    
	    BasePage.isElementVisible(locator_safeHarbor, driver);
	    
	    BasePage.isElementVisible(locator_sitemap, driver);
	}
	
	public void TC_2_5(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{

		/******************** Locators for Copyright components *****************/
		By locator_CopyrightLink=BasePage.getLocator(CopyrightLink,  BY_TYPE.BY_XPATH,driver);
		
		/******************** Copyright components verification *****************/
		
		BasePage.isElementVisible(locator_CopyrightLink, driver);
	}
	
}

