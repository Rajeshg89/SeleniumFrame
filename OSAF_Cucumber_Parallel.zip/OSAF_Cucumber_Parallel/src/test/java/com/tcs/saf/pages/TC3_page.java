package com.tcs.saf.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC3_page 

{	
	//Windows properties
	private static final String Services = ".//*[@id='mainnav']/li[1]/a";
	private static final String VerifyServices = ".//*[@id='overview']/h1";
	private static final String AssuranceServices = ".//*[@id='mainnav']/li[1]/div/ul/li[1]/a";
	private static final String VerifyAssuranceServices = ".//*[@id='overview']/h1";
	private static final String platformSolution = ".//*[@id='mainnav']/li[1]/div/ul/li[13]/a";
	private static final String VerifyPlatfromSolution = ".//*[@id='main']/div/h1";
	
	public void TC_3_1(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Services=BasePage.getLocator(Services,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyServices=BasePage.getLocator(VerifyServices,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.maximizeWindow(driver);
			BasePage.delay(1000);
			
			BasePage.click(locator_Services, driver);
			BasePage.delay(3000);
			
			BasePage.isElementVisible(locator_VerifyServices, driver);
			BasePage.delay(3000);
	}
	
	public void TC_3_2(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Services=BasePage.getLocator(Services,  BY_TYPE.BY_XPATH,driver);
		By locator_AssuranceServices=BasePage.getLocator(AssuranceServices,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyAssuranceServices=BasePage.getLocator(VerifyAssuranceServices,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.mouseOver(locator_Services, driver);
		
			
			BasePage.click(locator_AssuranceServices, driver);
			BasePage.delay(3000);
			
			
			BasePage.isElementVisible(locator_VerifyAssuranceServices, driver);
			BasePage.delay(2000);
	}
	
	public void TC_3_3(WebDriver driver) throws InterruptedException, FindFailed
	{
		By locator_Services=BasePage.getLocator(Services,  BY_TYPE.BY_XPATH,driver);
		By locator_platformSolution=BasePage.getLocator(platformSolution,  BY_TYPE.BY_XPATH,driver);   
		By locator_VerifyPlatfromSolution=BasePage.getLocator(VerifyPlatfromSolution,  BY_TYPE.BY_XPATH,driver);
		
		
			BasePage.mouseOver(locator_Services, driver);
			
			
			BasePage.click(locator_platformSolution, driver);
			BasePage.delay(3000);
			
			BasePage.getWindowHandle(driver);
			BasePage.switchToWindow(driver);
			
			BasePage.isElementVisible(locator_VerifyPlatfromSolution, driver);
			BasePage.delay(3000);
			
	}
	
}
