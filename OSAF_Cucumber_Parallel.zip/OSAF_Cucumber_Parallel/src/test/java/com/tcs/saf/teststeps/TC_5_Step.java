

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_4_CucumberPage;
import com.tcs.saf.pages.TC_5_CucumberPage;
import com.tcs.saf.test.TC1Cucumber;
import com.tcs.saf.test.TC5Cucumber;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_5_Step extends TC5Cucumber {
	
	TC_5_CucumberPage page = new TC_5_CucumberPage();
	
	
	@Given("^user is on TCS homepage five$")
	public void user_is_on_TCS_homepage_five() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify page redirect to TCSAdvantage hovering AboutTCS$")
	
	public void user_verify_page_redirect_to_TCSAdvantage_hovering_AboutTCS() throws Throwable {
		
		page.TC_5_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to TCSAdvantage hovering AboutTCS");
	
	}
	@And("^user verify page redirect to HeritageValues hovering AboutTCS$")
	
	public void user_verify_page_redirect_to_Government_hovering_AboutTCS() throws Throwable {
		
		page.TC_5_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to HeritageValues hovering AboutTCS");
	
	}
	@And("^user verify page redirect to Research hovering AboutTCS$")
	
	public void user_verify_page_redirect_to_Insurance_hovering_AboutTCS() throws Throwable {
	
		page.TC_5_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to Research hovering AboutTCS");
	
	}
@And("^user verify page redirect to CorporateSustainability hovering AboutTCS$")
	
	public void user_verify_page_redirect_to_Manufacturing_hovering_AboutTCS() throws Throwable {
	
		page.TC_5_4(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to CorporateSustainability hovering AboutTCS");
	
	}
	


}
