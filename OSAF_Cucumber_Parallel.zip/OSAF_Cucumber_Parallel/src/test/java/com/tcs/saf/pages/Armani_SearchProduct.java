package com.tcs.saf.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.sikuli.script.FindFailed;
import org.testng.Assert;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class Armani_SearchProduct 

{	
	//Windows properties
	private static final String searchIcon ="//*[@id='topHeadUser']/ul/li[4]";

	private static final String searchInput ="//*[@id='textSearch']";
	private static final String searchbutton ="//*[@id='textSearchForm']/button";
	
	

/*	public void loginFlipkart(String username,String password,WebDriver driver) throws InterruptedException, FindFailed
	{
		
		    BasePage.maximizeWindow(driver);
			By locator_loginbutton=BasePage.getLocator(loginbutton,  BY_TYPE.BY_XPATH,driver);
			By locator_userName = BasePage.getLocator(userName, BY_TYPE.BY_XPATH,driver);
			By locator_Password = BasePage.getLocator(Password, BY_TYPE.BY_XPATH,driver);
			By locator_login = BasePage.getLocator(login, BY_TYPE.BY_XPATH,driver);
		    BasePage.click(locator_loginbutton,driver);
		    BasePage.delay(3000);
		    BasePage.type(locator_userName, username,driver);
			//addExplicitWait(locator_userName, "visibility", 10);
		    BasePage.type(locator_Password, password,driver);
		    BasePage.addExplicitWait(locator_Password, "visibility", 10,driver);
		    BasePage.click(locator_login,driver);
		    BasePage.delay(5000);
			

	}*/
	public void clicksearch(String product,WebDriver driver) throws InterruptedException{
		By loc_srcIcon = BasePage.getLocator(searchIcon, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_srcIcon, "visibility", 20,driver);
		BasePage.click(loc_srcIcon,driver);

		By loc_srcInput = BasePage.getLocator(searchInput, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_srcInput, "visibility", 20,driver);
		BasePage.type(loc_srcInput, product,driver);
		BasePage.delay(2000);
	

		By loc_srcbutton = BasePage.getLocator(searchbutton, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(loc_srcbutton, "visibility", 20,driver);
		BasePage.click(loc_srcbutton,driver);
		BasePage.delay(2000);
	}
	
	
	
}
