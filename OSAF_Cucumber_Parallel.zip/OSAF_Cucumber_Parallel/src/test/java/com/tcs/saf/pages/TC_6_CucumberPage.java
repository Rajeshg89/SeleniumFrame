package com.tcs.saf.pages;
import org.bouncycastle.jcajce.provider.symmetric.ARC4.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC_6_CucumberPage 

{	
	
	private static final String Resources = ".//*[@id='mainnav']/li[6]/a";
	private static final String casestudies = ".//*[@id='mainnav']/li[6]/div/ul/li[1]/a";
	private static final String Verifycasestudies = ".//*[@id='theTitle']";
	private static final String WhitePaper = ".//*[@id='mainnav']/li[6]/div/ul/li[2]/a";
	private static final String VerifyWhitePaper = ".//*[@id='theTitle']";
	private static final String Newsletter = ".//*[@id='mainnav']/li[6]/div/ul/li[5]/a";
	private static final String VerifyNewsletter = ".//*[@id='theTitle']";
	private static final String podcast = ".//*[@id='mainnav']/li[6]/div/ul/li[3]/a";
	private static final String Verifypodcast = ".//*[@id='theTitle']";

	
	
	public void TC_6_1(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_Resources=BasePage.getLocator(Resources,  BY_TYPE.BY_XPATH,driver);
		By locator_casestudies=BasePage.getLocator(casestudies,  BY_TYPE.BY_XPATH,driver);
		By locator_Verifycasestudies=BasePage.getLocator(Verifycasestudies,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.maximizeWindow(driver);
			BasePage.delay(5000);
			
			BasePage.mouseOver(locator_Resources, driver);
			
			BasePage.click(locator_casestudies, driver);
			BasePage.delay(1000);
			
			BasePage.isElementVisible(locator_Verifycasestudies, driver);
			BasePage.delay(1000);
	}
	
	public void TC_6_2(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_Resources=BasePage.getLocator(Resources,  BY_TYPE.BY_XPATH,driver);
		By locator_WhitePaper=BasePage.getLocator(WhitePaper,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyWhitePaper=BasePage.getLocator(VerifyWhitePaper,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Resources, driver);
		
		BasePage.click(locator_WhitePaper, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyWhitePaper, driver);
		BasePage.delay(1000);
	}
	
	public void TC_6_3(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_Resources=BasePage.getLocator(Resources,  BY_TYPE.BY_XPATH,driver);
		By locator_Newsletter=BasePage.getLocator(Newsletter,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyNewsletter=BasePage.getLocator(VerifyNewsletter,  BY_TYPE.BY_XPATH,driver);
		
		
			BasePage.mouseOver(locator_Resources, driver);
			
			
			BasePage.click(locator_Newsletter, driver);
			BasePage.delay(3000);
			
			
			BasePage.isElementVisible(locator_VerifyNewsletter, driver);
			BasePage.delay(3000);
			
			
	}
	
	public void TC_6_4(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_Resources=BasePage.getLocator(Resources,  BY_TYPE.BY_XPATH,driver);
		By locator_podcast=BasePage.getLocator(podcast,  BY_TYPE.BY_XPATH,driver);
		By locator_Verifypodcast=BasePage.getLocator(Verifypodcast,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_Resources, driver);
		
		
		BasePage.click(locator_podcast, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_Verifypodcast, driver);
		BasePage.delay(1000);
	}
	
}
