package com.tcs.saf.pages;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC_1_CucumberPage 

{	

	private static final String worldwide = ".//*[@id='globalnav']/li[1]/a";
	private static final String careers = ".//*[@id='globalnav']/li[2]/a";
	private static final String investors = ".//*[@id='globalnav']/li[3]/a";
	private static final String contactus = ".//*[@id='globalnav']/li[5]/a";
	private static final String contactswitchverification = ".//*[@id='ctl00_PlaceHolderMain_siteMapPath']/span[3]";
	private static final String share = ".//a[contains(text(),'Share')]";
	private static final String twitter = "//span[contains(.,'Twitter')]";
	private static final String linkedin = "//span[contains(.,'LinkedIn')]";
	private static final String favourites = "//span[contains(.,'Favorites')]";
	private static final String digg = "//span[contains(.,'Digg')]";
	private static final String delicious = "//span[contains(.,'Delicious')]";
	private static final String myspace = "//span[contains(.,'Myspace')]";
	private static final String facebook = "//span[contains(.,'Facebook')]";
	private static final String more = "//span[contains(.,'More... (199)')]";
	private static final String search =".//*[@id='searchinput']";
	private static final String searchbtn =".//*[@id='searchbtn']";
	
	public void TC_1_1(WebDriver driver,ExtentTest test) throws  FindFailed
	{
		try{
		By locator_worldwide=BasePage.getLocator(worldwide,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.maximizeWindow(driver);
			BasePage.delay(1000);
			BasePage.isElementVisible(locator_worldwide, driver);
			test.log(LogStatus.PASS, "worldwide is Visible", "Test is verified");
		}
		catch (Exception ex){
			test.log(LogStatus.FAIL, "worldwide is not Visible", "Test failed");
		}
	}
	
	public void TC_1_2(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed, ClientHandlerException, IOException
	{
		By locator_careers=BasePage.getLocator(careers,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.isElementVisible(locator_careers, driver);
	}
	
	public void TC_1_3(WebDriver driver,ExtentTest test) throws FindFailed
	{
		By locator_investors=BasePage.getLocator(investors,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.isElementVisible(locator_investors, driver);
	}
	
	public void TC_1_4(WebDriver driver,ExtentTest test) throws  FindFailed, InterruptedException
	{
		By locator_contactus=BasePage.getLocator(contactus,  BY_TYPE.BY_XPATH,driver);
		By locator_contactswitchverification=BasePage.getLocator(contactswitchverification,  BY_TYPE.BY_XPATH,driver);
				
		BasePage.isElementVisible(locator_contactus, driver);	
		
		 BasePage.click(locator_contactus, driver);
		 BasePage.delay(4000);
		 BasePage.isElementVisible(locator_contactswitchverification, driver);
		 BasePage.delay(4000);
	}
	
	public void TC_1_5(String Text,WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		try{
		By locator_share=BasePage.getLocator(share,  BY_TYPE.BY_XPATH,driver);
		By locator_twitter=BasePage.getLocator(twitter,  BY_TYPE.BY_XPATH,driver);
		By locator_linkedin=BasePage.getLocator(linkedin,  BY_TYPE.BY_XPATH,driver);
		By locator_favourites=BasePage.getLocator(favourites,  BY_TYPE.BY_XPATH,driver);
		By locator_digg=BasePage.getLocator(digg,  BY_TYPE.BY_XPATH,driver);
		By locator_delicious=BasePage.getLocator(delicious,  BY_TYPE.BY_XPATH,driver);
		By locator_myspace=BasePage.getLocator(myspace,  BY_TYPE.BY_XPATH,driver);
		By locator_facebook=BasePage.getLocator(facebook,  BY_TYPE.BY_XPATH,driver);
		By locator_more=BasePage.getLocator(more,  BY_TYPE.BY_XPATH,driver);
		By locator_search=BasePage.getLocator(search,  BY_TYPE.BY_XPATH,driver);
		By locator_searchbtn=BasePage.getLocator(searchbtn,  BY_TYPE.BY_XPATH,driver);
		
		 
	    BasePage.isElementVisible(locator_share, driver);
	    
	    BasePage.addExplicitWait(locator_share, "visibility", 5, driver);
	    BasePage.mouseOver(locator_share, driver);
	    
	    BasePage.isElementVisible(locator_twitter, driver);
	    
	    BasePage.isElementVisible(locator_linkedin, driver);
	    
	    BasePage.isElementVisible(locator_favourites, driver);
	    
	    BasePage.isElementVisible(locator_digg, driver);
	    
	    BasePage.isElementVisible(locator_delicious, driver);
	    
	    BasePage.isElementVisible(locator_myspace, driver);
	    
	    BasePage.isElementVisible(locator_facebook, driver);
	    
	    BasePage.isElementVisible(locator_more, driver);
	    
	    BasePage.type(locator_search,Text, driver);
	    
	    BasePage.click(locator_searchbtn, driver);
	    test.log(LogStatus.PASS, "Sublink is visible", "Test is verified");
		}
		catch (Exception ex){
			test.log(LogStatus.FAIL, "Sublink is not Visible", "Test failed");
		}
	    
	    
	}
}
