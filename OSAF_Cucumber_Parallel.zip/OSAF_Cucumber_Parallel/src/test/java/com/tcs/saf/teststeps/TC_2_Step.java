

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_2_CucumberPage;
import com.tcs.saf.pages.TC_3_CucumberPage;
import com.tcs.saf.test.TC1Cucumber;
import com.tcs.saf.test.TC2Cucumber;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_2_Step extends TC2Cucumber {
	
	TC_2_CucumberPage page = new TC_2_CucumberPage();
	
	
	@Given("^user is on TCS homepage two$")
	public void user_is_on_TCS_homepage_two() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify the sub links under services present$")
	
	public void user_verify_the_sub_links_under_services_present() throws Throwable {
		
		page.TC_2_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the sub links under services present");
	
	}
	@And("^user verify the sub links under industries present$")
	
	public void user_verify_the_sub_links_under_industries_present() throws Throwable {
		
		page.TC_2_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the sub links under industries present");
	
	}
	@And("^user verify the sub links under software present$")
	
	public void user_verify_the_sub_links_under_software_present() throws Throwable {
		
		page.TC_2_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified  the sub links under software present");
	
	}
	@And("^user verify the sub links under connectwithus present$")
	
	public void user_verify_the_sub_links_under_connectwithus_present() throws Throwable {

		page.TC_2_4(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the sub links under connectwithus present");
	
	}
	@And("^user verify the copy right text present$")
	
	public void user_verify_the_copy_right_text_present() throws Throwable {
		
		page.TC_2_5(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified the copy right text present");
	
	}
	
	

	
	

}
