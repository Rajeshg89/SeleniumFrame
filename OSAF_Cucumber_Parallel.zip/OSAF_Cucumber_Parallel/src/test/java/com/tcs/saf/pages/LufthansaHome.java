package com.tcs.saf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class LufthansaHome 

{	
	
	private static final String selectFields = ".//*[@id='ls-selection-btn']";
	private static final String country = ".//*[@id='cl-country']";
	//private static final String language = ".//*[@id='cl-language']";
	private static final String continue1 = ".//*[@id='cl-form']/button";

	
	public void selectfield(String countryname,String languagename,WebDriver driver) throws InterruptedException
	{
		    By locator_selectfields = BasePage.getLocator(selectFields, BY_TYPE.BY_XPATH,driver);
		    BasePage.click(locator_selectfields,driver);
		    BasePage.delay(2000);
		    
			By locator_country = BasePage.getLocator(country, BY_TYPE.BY_XPATH,driver);
			BasePage.selectDropDownByVisibleText(locator_country,countryname , driver);
			
			/*By locator_language = BasePage.getLocator(language, BY_TYPE.BY_XPATH,driver);
			BasePage.selectDropDownByVisibleText(locator_language,languagename, driver);*/
			
			By locator_continue1 = BasePage.getLocator(continue1, BY_TYPE.BY_XPATH,driver);
		    BasePage.click(locator_continue1,driver);
				
			
	}
	
}
