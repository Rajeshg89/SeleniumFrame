package com.tcs.saf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class JCPenney {

	public static String searchTxt = "[name='q']";

	public void tcs(String srchText, WebDriver driver, ExtentTest test) throws InterruptedException, FindFailed {
		try {
			By searchText = BasePage.getLocator(searchTxt, BY_TYPE.BY_CSSSELECTOR,driver);
			BasePage.type(searchText, srchText, driver);
			test.log(LogStatus.PASS, "Selenium HQ text is entered", "Test is verified");
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, "Selenium HQ text is not entered", "Test failed");
		}

	}

}
