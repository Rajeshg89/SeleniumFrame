
package com.tcs.saf.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import jxl.JXLException;
import jxl.read.biff.BiffException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.httpclient.auth.AuthenticationException;
import org.sikuli.script.FindFailed;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BaseTest;
import com.tcs.saf.base.BrowserSetUp;
import com.tcs.saf.exceptions.DataSheetException;
import com.tcs.saf.exceptions.InvalidBrowserException;
import com.tcs.saf.pages.TC4_page;
import com.tcs.saf.pages.TC5_page;
import com.tcs.saf.pages.TC6_page;
import com.tcs.saf.utilities.TestDataProvider;
public class TC_6 extends BaseTest {
	public static ExtentReports report;
	public static ExtentTest test;		
	public TC_6()
	{
		this.testDataProvider = new TestDataProvider();
		getGridProperties();
		getGlobalProperties();		
	}
	
	public TC_6(String testName,String browser, LinkedHashMap<String, String> mapDataSheet)
	{
		this.testName = testName;
		this.testDataProvider = new TestDataProvider();
		this.testBrowser = browser;
		this.mapDataSheet = mapDataSheet;
	}

	@Factory(dataProvider = "dataSheet")
	public Object[] testCreator(LinkedHashMap<String, String> mapDataSheet) {
		return new Object[] { new TC_6(this.getClass().getSimpleName(),mapDataSheet.get("Browser"), mapDataSheet) };
	}


	@DataProvider(name="dataSheet")
	public  Object[][] getTestData() throws BiffException, IOException, InvalidBrowserException, DataSheetException{
		return testDataProvider.getTestDataFromExcel(externalSheetPath, this.getClass().getSimpleName());
	}
	@BeforeMethod
	public void beforemethod() throws AuthenticationException, ClientHandlerException, IOException {	
		setMapDataSheet(mapDataSheet);
		webDriver = BrowserSetUp.setMyBrowser(this.testBrowser,testName,mapDataSheet,execution_Format);
		reportpath = globalProperties.getString("report_path");
		report = new ExtentReports(reportpath+"TC_6.html", false);
		test = TestReportGenerator(report,this.getClass().getSimpleName(),"Test Desciption");
	}	

	@Test
	public void sampleTest() throws InterruptedException, FindFailed, ClientHandlerException, IOException {				
		Reporter.log("Execution of test case using : "+ BrowserSetUp.getValue("TestCaseName",mapDataSheet,logger));	
		BasePage.launchPageURL(mapDataSheet.get("URL"),getDriver());	
		test.log(LogStatus.INFO, "TCS home page launched");
        Reporter.log("Launched the Application Under Test");
		
		
        TC6_page TC6 = new TC6_page();
        
		System.out.println("sheet is:" + mapDataSheet);
		TC6.TC_6_1(getDriver());
		test.log(LogStatus.INFO, "Verified TCS Case Studies page");
		TC6.TC_6_2(getDriver());
		test.log(LogStatus.INFO, "Verified TCS WhitePaper page");
		TC6.TC_6_3(getDriver());
		test.log(LogStatus.INFO, "Verified TCS Newsletter page");
		TC6.TC_6_4(getDriver());
		test.log(LogStatus.INFO, "Verified TCS Podcast page");
		
		
		}
	@AfterMethod
	public void afterMethod(ITestResult testResult)
			throws SQLException, BiffException, IOException, RowsExceededException, JXLException {
		BrowserSetUp.terminateTest(testResult,this.testBrowser,test,report,getDriver());
	}
}	
