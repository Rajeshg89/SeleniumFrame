

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.TC_7_CucumberPage;
import com.tcs.saf.test.TC7Cucumber;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class TC_7_Step extends TC7Cucumber {
	
	TC_7_CucumberPage page = new TC_7_CucumberPage();
	
	
	@Given("^user is on TCS homepage seven$")
	
	public void user_is_on_TCS_homepage_seven() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "TCS home page launched");
	   
	}

	@Then("^user verify page redirect to EcperienceCertainity hovering AboutTCS$")
	
	public void user_verify_page_redirect_to_EcperienceCertainity_hovering_AboutTCS() throws Throwable {
		
		page.TC_7_1(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified page redirect to EcperienceCertainity hovering AboutTCS");
	
	}
	@And("^user verify canada is present under North America on the worldwide page$")
	
	public void user_verify_page_redirect_to_WhitePaper_hovering_Resources() throws Throwable {
		
		page.TC_7_2(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified canada is present under North America on the worldwide page");
	
	}
	@And("^user verify sharelink RSSFeed printpage emailthis present on the EcperienceCertainity page$")
	
	public void user_verify_page_redirect_to_Newsletter_hovering_Resources() throws Throwable {
	
		page.TC_7_3(getDriver(),test);
		test.log(LogStatus.INFO, "successfuly verified sharelink RSSFeed printpage emailthis present on the EcperienceCertainity page");
	
	}


}
