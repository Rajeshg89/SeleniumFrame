package com.tcs.saf.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


/**
 * This is a sample page object class that is used for testing.
 * 
 * @author TCS Automation CoE
 *
 */
public  class JCPLoginPage {

	public static String myAccountCSS = "[title='my account']";

	public static void SelectMyAccount(WebDriver driver,ExtentTest test) {
		By myAccount = BasePage.getLocator(myAccountCSS,BY_TYPE.BY_CSSSELECTOR,driver);
		try{
		BasePage.click(myAccount,driver);
		test.log(LogStatus.PASS, "My Account link Clicked", "Test is verified");
		}catch(Exception e){
		}
	}
	
}
