
package com.tcs.saf.teststeps;


import org.testng.Reporter;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.JCPLoginPage;
import com.tcs.saf.test.CucumberRunTestJCPenney;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/** 
 * This is sample glue/step definition class for reference. To be utilized for testing purpose only.
 * @author TCS Automation CoE
 *
 */

public class JCPLoginStep extends CucumberRunTestJCPenney{
	JCPLoginPage JCPLogin;
	@Given("^user is on JCPenny home page$")
	public void user_is_on_JCPenny_home_page() throws Throwable {
		BasePage.launchPageURL(getValue("URL"),getDriver());		
		test.log(LogStatus.INFO, "JCP home page launched");
		Reporter.log("The_user_is_on_JC Penney_search_page ::--> Passed");
	}

	@When("^user clicks the My account option$")
	public void user_clicks_the_My_account_option() throws Throwable {
		JCPLoginPage.SelectMyAccount(getDriver(),test);
	}

	@When("^user login with the valid \"(.*?)\" and \"(.*?)\"$")
	public void user_login_with_the_valid_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^page should shows the user \"(.*?)\"$")
	public void page_should_shows_the_user(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	
}
