
package com.tcs.saf.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.LinkedHashMap;

import jxl.JXLException;
import jxl.read.biff.BiffException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.httpclient.auth.AuthenticationException;
import org.json.JSONException;
//import org.sikuli.script.FindFailed;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;





import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.jersey.api.client.ClientHandlerException;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BaseTest;
import com.tcs.saf.base.BrowserSetUp;
import com.tcs.saf.exceptions.DataSheetException;
import com.tcs.saf.exceptions.InvalidBrowserException;
import com.tcs.saf.pages.TCS_Homepage_Menuoperations;
import com.tcs.saf.utilities.TestDataProvider;
import com.tcs.saf.utilities.Zapi.Status;



public class Homepage_menu_validation extends BaseTest {
	
	public static ExtentReports report;
	public static ExtentTest test;
   
	public Homepage_menu_validation()
	{
		super.testcaseLabel=this.getClass().getSimpleName();
		this.testDataProvider = new TestDataProvider();
		getGridProperties();
		getGlobalProperties();
		
	}
	
	public Homepage_menu_validation(String testName,String browser, LinkedHashMap<String, String> mapDataSheet)
	{
		this.testName = testName;
		this.testDataProvider = new TestDataProvider();
		this.testBrowser = browser;
		this.mapDataSheet = mapDataSheet;
	}

	@Factory(dataProvider = "dataSheet")
	public Object[] testCreator(LinkedHashMap<String, String> mapDataSheet) {
		return new Object[] { new Homepage_menu_validation(this.getClass().getSimpleName(),mapDataSheet.get("Browser"), mapDataSheet) };
	}


	@DataProvider(name="dataSheet")
	public  Object[][] getTestData() throws BiffException, IOException, InvalidBrowserException, DataSheetException{
		return testDataProvider.getTestDataFromExcel(externalSheetPath, this.getClass().getSimpleName());
	}
	@BeforeMethod
	public void beforemethod() throws AuthenticationException, ClientHandlerException, IOException {	
		setMapDataSheet(mapDataSheet);
		webDriver = BrowserSetUp.setMyBrowser(this.testBrowser,testName,mapDataSheet,execution_Format);
		reportpath = globalProperties.getString("report_path");
		report = new ExtentReports(reportpath+"TC_1.html", false);
		test = TestReportGenerator(report,this.getClass().getSimpleName(),"Test Desciption");
	}	

	@Test
	public void check_menu_items() throws InterruptedException, ClientHandlerException, IOException {				
		Reporter.log("Execution of test case using : "+ BrowserSetUp.getValue("TestCaseName",mapDataSheet,logger));	
		BasePage.launchPageURL(mapDataSheet.get("URL"),getDriver());	
		test.log(LogStatus.INFO, "TCS home page launched");
        Reporter.log("Launched the Application Under Test");
        TCS_Homepage_Menuoperations menu = new TCS_Homepage_Menuoperations();       
		System.out.println("sheet is:" + mapDataSheet);
		menu.checkForMenu_worldwide(getDriver());
		test.log(LogStatus.INFO, "Verified Worldwide link in TCS home page");
		menu.checkForMenu_careers(getDriver());
		test.log(LogStatus.INFO, "Verified careers link in TCS home page");
		
		menu.checkForMenu_contactus(getDriver());
		test.log(LogStatus.INFO, "Verified investors link in TCS home page");
		
		menu.checkForMenu_investors(getDriver());
		test.log(LogStatus.INFO, "Verified contactus link in TCS home page");
		
		menu.checkForMenu_share(getDriver());
		test.log(LogStatus.INFO, "Verified share link in TCS home page");
		
		}
	@AfterMethod
	public void afterMethod(ITestResult testResult)
			throws SQLException, BiffException, IOException, RowsExceededException, JXLException, JSONException {
		BrowserSetUp.terminateTest(testResult,this.testBrowser,test,report,getDriver());
		
		if(testResult.getStatus()==ITestResult.SUCCESS)
		{
			comment=testResult.getTestName()+": Passed";
			status=Status.PASS;
			updatestatus(134);
		}
		else if(testResult.getStatus()==ITestResult.FAILURE)
		{
			status=Status.FAIL;
		}
	}
}	
