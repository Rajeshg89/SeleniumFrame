

package com.tcs.saf.teststeps;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.pages.LufthansaCucumberPage;
import com.tcs.saf.test.LufthansaCucumber;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * This is sample glue/step definition class for reference. To be utilized for
 * testing purpose only.
 * 
 * @author TCS Automation CoE
 *
 */

public class LufthansaTestSteps extends LufthansaCucumber {
	
	LufthansaCucumberPage page = new LufthansaCucumberPage();
	
	
	@Given("^user is on Lufthansa home page$")
	public void user_is_on_Lufthansa_home_page() throws Throwable {
		BasePage.launchPageURL("http://www.lufthansa.com/",getDriver());
		BasePage.maximizeWindow(getDriver());
		test.log(LogStatus.INFO, "Lufthansa home page launched");
	   
	}

	@When("^select the fields \"(.*?)\" and \"(.*?)\"$")
	
	public void user_select_the_fields(String countryname,String languagename) throws Throwable {
		//String value = getValue("Text to Enter");
		//page.selectfield(getValue("countryname"),getValue("languagename"), getDriver(),test);
		page.selectfield(countryname,languagename,getDriver(),test);
	
	}
	@And("^try to register a user account$")
	public void user_try_to_register_a_user_account() throws Throwable{
		
		page.new_registeration(getDriver(), test);
	}
	@And("^enter the user details$")
	
	public void enter_the_user_details() throws Throwable{
	
		page.new_registeration1(getValue("title1"), getValue("firstname1"), getValue("lasttname1"), getValue("day1"), getValue("month1"), getValue("year1"), getValue("street1"), getValue("postalcode1"), getValue("city1"), getValue("areacode1"), getValue("phoneno1"), getValue("email1"), getValue("confirmemail1"), getValue("username1"), getValue("password1"), getValue("confirmPassword1"), getDriver(), test);
		
	}
	
	

}
