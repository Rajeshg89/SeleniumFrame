package com.tcs.saf.pages;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class Tcs_Page 

{	
	private static final String searchinput = "searchinput";
	private static final String searchbutton = "//*[@id='searchbtn']";
	private static final String careers = "//*[@id='globalnav']/li[5]/a";
	private static final String drop = "//*[@id='CandType']";
	private static final String valid ="//*[@id='contentSection']/div[2]/div[1]/div/div[1]";
	private static final String offerletter ="//*[@id='candOfferAuthSbView:candOfrFrm:candOfrRfId']";
	private static final String verify ="//*[@id='candOfferAuthSbView:candOfrFrm:cmdStdTmpt']";
	private static final String valid1 ="//*[@id='candOfferAuthSbView:candOfrFrm:candOfrPnlGrdCnt']/tbody/tr[1]/td/div/table/tbody/tr/td[2]/label";
	private static final String backtohome ="//*[@id='candOfferAuthSbView:candOfrFrm:cmdBkHmBtn']";
	private static final String know ="//*[@id='tileStripHtml0']/div/button";
	private static final String forgotpassword ="//*[@id='pageForm:_idJsp15']";
	private static final String email ="//*[@id='forgotPassword:forgotPasswordForm:authenticationParameter']/tbody/tr/td[2]/label/input";
	private static final String emailID ="//*[@id='forgotPassword:forgotPasswordForm:UserId']";
	private static final String Answer ="//*[@id='forgotPassword:forgotPasswordForm:txtsecurityAId']";
	private static final String submit ="//*[@id='forgotPassword:forgotPasswordForm:submitId']";
	
   
	
	
/*	public void search_product(String product_name,WebDriver driver) throws InterruptedException
	{
		By locator_search = BasePage.getLocator(searchinput, BY_TYPE.BY_XPATH,driver);
			//By locator_sbutton = BasePage.getLocator(searchbutton, BY_TYPE.BY_XPATH,driver);
			By locator_item = BasePage.getLocator(item, BY_TYPE.BY_XPATH,driver);
			BasePage.type(locator_search, product_name,driver);
			//BasePage.click(locator_sbutton,driver);
			driver.findElement(By.xpath(".//*[@name='q']")).sendKeys(Keys.ENTER);
			BasePage.delay(10000);
			List<WebElement> searchResults=driver.findElements(By.xpath("((//div[@data-aid='searchresults_products-container']/div[contains(.,'')])[3]/div[contains(.,'')])[1]/div[contains(@data-aid,'product_list_unit')]"));
			int sizeSearchResults=searchResults.size();
			Assert.assertTrue("Search results not found", sizeSearchResults>0);
			BasePage.click(locator_item,driver);
			BasePage.delay(5000);
		
			
	}*/
	public void tcsHomePage(String searchbox,WebDriver driver) throws InterruptedException
	{
		BasePage.maximizeWindow(driver) ;
		By locator_searchbox = BasePage.getLocator(searchinput, BY_TYPE.BY_ID,driver);
		By locator_clicksearch = BasePage.getLocator(searchbutton, BY_TYPE.BY_XPATH,driver);
		By locator_clickcareers = BasePage.getLocator(careers, BY_TYPE.BY_XPATH,driver);
		By locator_selectdropdown = BasePage.getLocator(drop, BY_TYPE.BY_XPATH,driver);
		By locator_valid = BasePage.getLocator(valid, BY_TYPE.BY_XPATH,driver);
	

		//To perform typeaction with sikuli
		//sikulitype("C:\\984421\\StommeAdvancedBuild\\SikuliImages\\search2.PNG",searchbox);
		//To pass on a parameter into a text feild
		BasePage.type(locator_searchbox, searchbox,driver);
		BasePage.delay(5000);
		BasePage.click(locator_clicksearch,driver);
		BasePage.delay(10000);
		BasePage.addExplicitWait(locator_clickcareers, "visibility", 10,driver);
		BasePage.click(locator_clickcareers,driver);
		BasePage.delay(10000);
		String msg=BasePage.getText(locator_valid,driver);
		Assert.assertEquals("Is your Offer Letter genuine ?", msg);
		BasePage.addExplicitWait(locator_selectdropdown, "visibility", 10,driver);
		BasePage.selectDropDownByVisibleText(locator_selectdropdown, "Experienced Professional",driver);
		BasePage.delay(10000);
		
		//To get the child window to perform a switch 
		BasePage.getWindowHandle(driver);
		BasePage.delay(2000);
		BasePage.switchToWindow(driver);
		
		
	}
	public void checkOffer(String offerNO,WebDriver driver) throws InterruptedException
	{
		By locator_offerletter = BasePage.getLocator(offerletter, BY_TYPE.BY_XPATH,driver);
		By locator_valid1 = BasePage.getLocator(valid1, BY_TYPE.BY_XPATH,driver);
		By locator_verify = BasePage.getLocator(verify, BY_TYPE.BY_XPATH,driver);
		By locator_back = BasePage.getLocator(backtohome, BY_TYPE.BY_XPATH,driver);	
		
		BasePage.type(locator_offerletter, offerNO,driver);
		BasePage.click(locator_verify,driver);
		String msg1=BasePage.getText(locator_valid1,driver);
		Assert.assertEquals("Please enter the text as shown below.", msg1);
		BasePage.click(locator_back,driver);
		BasePage.delay(3000);
	}
	
	public void forgotpassword(String Email,String Sec_Qus,String Ans,WebDriver driver) throws InterruptedException
	{
		By locator_know = BasePage.getLocator(know, BY_TYPE.BY_XPATH,driver);
		By locator_forgotpassword = BasePage.getLocator(forgotpassword, BY_TYPE.BY_XPATH,driver);
		By locator_email = BasePage.getLocator(email, BY_TYPE.BY_XPATH,driver);
		By locator_emailID =BasePage. getLocator(emailID, BY_TYPE.BY_XPATH,driver);
		By locator_Answer = BasePage.getLocator(Answer, BY_TYPE.BY_XPATH,driver);
		By locator_submit = BasePage.getLocator(submit, BY_TYPE.BY_XPATH,driver);	
		
		BasePage.delay(3000);
		BasePage.click(locator_know,driver);
		BasePage.delay(10000);
		BasePage.getWindowHandle(driver);
		BasePage.delay(2000);
		BasePage.switchToWindow(driver);
		BasePage.delay(2000);
		BasePage.click(locator_forgotpassword,driver);
		BasePage.delay(2000);
		BasePage.click(locator_email,driver);
		BasePage.delay(2000);
		BasePage.type(locator_emailID, Email,driver);
		BasePage.delay(2000);
		BasePage.type(locator_Answer,Ans,driver);
		BasePage.delay(2000);
		BasePage.click(locator_submit,driver);
	}
	

	
}
