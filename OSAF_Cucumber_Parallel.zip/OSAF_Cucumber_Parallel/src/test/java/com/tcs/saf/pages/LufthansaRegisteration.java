package com.tcs.saf.pages;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

public class LufthansaRegisteration 

{	
	
	private static final String loginIcon = ".//*[@id='header-profile-toggle']";
	private static final String keepmelogin = ".//*[@id='ll-remember-me']";
	private static final String newRegisteration = ".//*[@id='loginUserdataForm']/div[5]/div/h3/a";
	private static final String tilte = ".//*[@id='pesalutation']";
	private static final String academictitle = ".//*[@id='peacademicTitle']";
	private static final String firstname = ".//*[@id='pefirstName']";
	private static final String lastname = ".//*[@id='pelastName']";
	private static final String day = ".//*[@id='peday']";
	private static final String month = ".//*[@id='pemonth']";
	private static final String year = ".//*[@id='peyear']";
	private static final String residence = ".//*[@id='pecountry']";
	private static final String street = ".//*[@id='pestreet']";
	private static final String postalcode = ".//*[@id='pezip']";
	private static final String city = "//*[@id='pecity']";
	private static final String typeofphone = ".//*[@id='pephoneType']";
	private static final String countrycode = ".//*[@id='pecountryCode']";
	private static final String areacode = ".//*[@id='peareaCode']";
	private static final String phoneno = ".//*[@id='pephoneNumber']";
	private static final String email = ".//*[@id='peemail']";
	private static final String confirmemail = ".//*[@id='peemailR']";
	private static final String username = ".//*[@id='peusername']";
	private static final String password = ".//*[@id='pepassword']";
	private static final String confirmPassword = ".//*[@id='pepasswordR']";
	private static final String continue2 = ".//*[@id='pesubmit']";
	private static final String donot = ".//*[@id='pemmoptions-n']";
	private static final String termsandcondition =".//*[@id='pemam-terms-conditions']";
	private static final String submit =".//*[@id='pesubmit']";
	private static final String validate="//*[@id='contentpage']/div/div[1]/div[2]/p[2]";
	
	
	public void new_registeration(WebDriver driver) throws InterruptedException
	{
		    By locator_loginIcon = BasePage.getLocator(loginIcon, BY_TYPE.BY_XPATH,driver);
		    BasePage.click(locator_loginIcon,driver);
		    
			By locator_keepmelogin = BasePage.getLocator(keepmelogin, BY_TYPE.BY_XPATH,driver);
			   BasePage.click(locator_keepmelogin,driver);
			   
			By locator_newRegisteration = BasePage.getLocator(newRegisteration, BY_TYPE.BY_XPATH,driver);
			   BasePage.click(locator_newRegisteration,driver);

				
	}
	public void new_registeration1(String title1,String firstname1,String lasttname1,String day1,String month1,String year1,String street1,String postalcode1,String city1,String areacode1,String phoneno1,String email1,String confirmemail1,String username1,String password1,String confirmPassword1,WebDriver driver) throws InterruptedException{
		By locator_tilte=BasePage.getLocator(tilte, BY_TYPE.BY_XPATH, driver);
		BasePage.selectDropDownByVisibleText(locator_tilte, title1, driver);
		
		By locator_firstname=BasePage.getLocator(firstname, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_firstname, firstname1, driver);
		
		By locator_lastname=BasePage.getLocator(lastname, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_lastname, lasttname1, driver);
		
		By locator_day=BasePage.getLocator(day, BY_TYPE.BY_XPATH, driver);
		BasePage.selectDropDownByVisibleText(locator_day, day1, driver);
		
		By locator_month=BasePage.getLocator(month, BY_TYPE.BY_XPATH, driver);
		BasePage.selectDropDownByVisibleText(locator_month, month1, driver);
		
		By locator_year=BasePage.getLocator(year, BY_TYPE.BY_XPATH, driver);
		BasePage.selectDropDownByVisibleText(locator_year, year1, driver);
		
		By locator_street=BasePage.getLocator(street, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_street, street1, driver);
		BasePage.delay(2000);
		
		By locator_postalcode=BasePage.getLocator(postalcode, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_postalcode, postalcode1, driver);
		BasePage.delay(2000);
		
		By locator_city=BasePage.getLocator(city, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_city, city1, driver);
		BasePage.delay(2000);
		
		By locator_areacode=BasePage.getLocator(areacode, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_areacode, areacode1, driver);
		
		By locator_phoneno=BasePage.getLocator(phoneno, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_phoneno, phoneno1, driver);
		
		int run;
		run = 100 + (int)(Math.random() * ((10000 - 100) + 1));
		By locator_email=BasePage.getLocator(email, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_email, email1+run+"@gmail.com", driver);
		
		By locator_confirmemail=BasePage.getLocator(confirmemail, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_confirmemail,confirmemail1+run+"@gmail.com" , driver);
		
		By locator_username=BasePage.getLocator(username, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_username, username1+run , driver);
		BasePage.delay(2000);
		
		By locator_password=BasePage.getLocator(password, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_password, password1, driver);
		BasePage.delay(2000);
		
		By locator_confirmPassword=BasePage.getLocator(confirmPassword, BY_TYPE.BY_XPATH, driver);
		BasePage.type(locator_confirmPassword, confirmPassword1, driver);
		BasePage.delay(5000);
		
		By locator_continue2 = BasePage.getLocator(continue2, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(locator_continue2, "visibility", 20,driver);
	    BasePage.clickUsingJavascriptExecutor(locator_continue2,driver);
	    
		By locator_donot= BasePage.getLocator(donot, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(locator_donot, "visibility", 20,driver);
	    BasePage.clickUsingJavascriptExecutor(locator_donot,driver);
	    
	    By locator_termsandcondition= BasePage.getLocator(termsandcondition, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(locator_termsandcondition, "visibility", 20,driver);
	    BasePage.clickUsingJavascriptExecutor(locator_termsandcondition,driver);
	    
	    By locator_submit= BasePage.getLocator(submit, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(locator_submit, "visibility", 20,driver);
	    BasePage.clickUsingJavascriptExecutor(locator_submit,driver);
	    
	    By locator_validate= BasePage.getLocator(validate, BY_TYPE.BY_XPATH,driver);
		BasePage.addExplicitWait(locator_validate, "visibility", 20,driver);
	    if(BasePage.getText(locator_validate,driver).equals("Welcome"+username1+run))
	    {
	    	System.out.println("Account is created successfully");
	    }
	    else
	    {
	    	System.out.println("Account creation is failed");
	    }
	    		
	    
	}
	
}

