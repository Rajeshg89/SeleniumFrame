package com.tcs.saf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;

/**
 * This is a sample page object class that is used for testing.
 * 
 * @author TCS Automation CoE
 *
 */
public class GoogleSearchPage {

	public static String searchTxt = "lst-ib";


	public static void ProductSearch(String srchText,WebDriver driver,ExtentTest test) {
		try {
			By searchText = BasePage.getLocator(searchTxt, BY_TYPE.BY_ID,driver);
			BasePage.type(searchText, srchText, driver);
			//searchText.sendKeys(srchText);
			Thread.sleep(4000);
			test.log(LogStatus.PASS, "Selenium HQ text is entered", "Test is verified");
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, "Selenium HQ text is not entered", "Test failed");
		}

	}

}
