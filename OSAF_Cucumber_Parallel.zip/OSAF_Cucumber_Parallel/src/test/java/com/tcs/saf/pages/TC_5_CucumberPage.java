package com.tcs.saf.pages;
import org.bouncycastle.jcajce.provider.symmetric.ARC4.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.FindFailed;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.tcs.saf.base.BasePage;
import com.tcs.saf.base.BasePage.BY_TYPE;


public class TC_5_CucumberPage 

{	
	//Windows properties 
	private static final String AboutTCS = "//a[contains(.,'About TCS�')]";
	private static final String TCSAdvantage = ".//*[@id='mainnav']/li[5]/div/ul/li[2]/a";
	private static final String VerifyTCSAdvantage = ".//*[@id='overview']/h1";
	private static final String HeritageValues = ".//*[@id='mainnav']/li[5]/div/ul/li[5]/a";
	private static final String VerifyHeritageValues = ".//*[@id='overview']/h1";
	private static final String Research = ".//*[@id='mainnav']/li[5]/div/ul/li[6]/a";
	private static final String VerifyResearch = ".//*[@id='main']/div/h1";
	private static final String CorporateSustainability = ".//*[@id='mainnav']/li[5]/div/ul/li[7]/a";
	private static final String VerifySustainabilityStrategy = ".//*[@id='post-203']/div/div[1]/div[2]/div[1]/section[1]/h5";


	public void TC_5_1(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_AboutTCS=BasePage.getLocator(AboutTCS,  BY_TYPE.BY_XPATH,driver);
		By locator_TCSAdvantage=BasePage.getLocator(TCSAdvantage,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyTCSAdvantage=BasePage.getLocator(VerifyTCSAdvantage,  BY_TYPE.BY_XPATH,driver);
		
			BasePage.maximizeWindow(driver);
			BasePage.delay(2000);
			
			BasePage.mouseOver(locator_AboutTCS, driver);
			
			BasePage.click(locator_TCSAdvantage, driver);
			BasePage.delay(1000);
			
			BasePage.isElementVisible(locator_VerifyTCSAdvantage, driver);
			BasePage.delay(1000);
	}
	
	public void TC_5_2(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_AboutTCS=BasePage.getLocator(AboutTCS,  BY_TYPE.BY_XPATH,driver);
		By locator_HeritageValues=BasePage.getLocator(HeritageValues,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyHeritageValues=BasePage.getLocator(VerifyHeritageValues,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_AboutTCS, driver);
		
		BasePage.click(locator_HeritageValues, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifyHeritageValues, driver);
		BasePage.delay(1000);
	}
	
	public void TC_5_3(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_AboutTCS=BasePage.getLocator(AboutTCS,  BY_TYPE.BY_XPATH,driver);
		By locator_Research=BasePage.getLocator(Research,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifyResearch=BasePage.getLocator(VerifyResearch,  BY_TYPE.BY_XPATH,driver);
		
		
			BasePage.mouseOver(locator_AboutTCS, driver);
			
			
			BasePage.click(locator_Research, driver);
			BasePage.delay(3000);
			
			
			BasePage.isElementVisible(locator_VerifyResearch, driver);
			BasePage.delay(3000);
			
			
	}
	
	public void TC_5_4(WebDriver driver,ExtentTest test) throws InterruptedException, FindFailed
	{
		By locator_AboutTCS=BasePage.getLocator(AboutTCS,  BY_TYPE.BY_XPATH,driver);
		By locator_CorporateSustainability=BasePage.getLocator(CorporateSustainability,  BY_TYPE.BY_XPATH,driver);
		By locator_VerifySustainabilityStrategy=BasePage.getLocator(VerifySustainabilityStrategy,  BY_TYPE.BY_XPATH,driver);
		
		BasePage.mouseOver(locator_AboutTCS, driver);
		
		
		BasePage.click(locator_CorporateSustainability, driver);
		BasePage.delay(1000);
		
		BasePage.isElementVisible(locator_VerifySustainabilityStrategy, driver);
		BasePage.delay(1000);
	}
	
}
