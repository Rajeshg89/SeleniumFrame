package com.tcs.saf.exceptions;

@SuppressWarnings("serial")
public class InvalidBrowserException extends Exception
{


	public InvalidBrowserException(String message)
	  {
	    super(message);
	  }

}
