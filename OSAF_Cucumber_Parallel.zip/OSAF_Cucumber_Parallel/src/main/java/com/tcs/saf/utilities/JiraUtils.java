package com.tcs.saf.utilities;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.auth.AuthenticationException;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;
import com.tcs.saf.base.BaseTest;



public class JiraUtils {
	/*
	 * Below Methods will help user to create a issue In JIRA. It will check the
	 * issue is already exist in JIRA project . If the bug is already Exist then
	 * it wont create a new issue inorder to avoid duplication of issue. If the
	 * Issue not exist , then a New issue will be created and corresponding JIRA
	 * id will be printed in console. After Creation of issue it will upload the
	 * attachment of screenshot to the bug which will be fetched from failed
	 * Testcase Once the Attachment is uploaded, it will map the New bug with
	 * Test case
	 */

	public static String CreateissueURL = "http://01hw612539vm1:8080/rest/api/2/issue/";
	public static String SearchissueURL = "http://01hw612539vm1:8080/rest/api/2/search?jql=project=\"STOM\"";
	public static String SearchTestcaseURL = "http://01hw612539vm1:8080/rest/api/2/search?jql=labels%20%3D%20";
	public static String UploadAttachmentURL = "http://01hw612539vm1:8080/rest/api/2/issue/";
	public static String LinkIssueURL = "http://01hw612539vm1:8080/rest/api/2/issueLink";
	public static String Uname = "rajesh";
	public static String Password = "tcs@123";
	public static String ProjectKey = "STOM";

	public static void CreateIssue(String Summaryfrombug,
			String BugDescriptionfromlog, String LabelNameofTestcase)
			throws AuthenticationException, ClientHandlerException, IOException {
		String Description = BugDescriptionfromlog;
		String BugSummary = Summaryfrombug;
		String AttachmentPath = System.getProperty("user.dir")
				+ "ExtentReport\\screenshot";
		String ScreenshotPath = AttachmentPath + "\\" + LabelNameofTestcase
				+ ".png";
		System.out.println("Screenshot Path::  " + ScreenshotPath);
		Client client1 = Client.create();
		// A boolean check to know issue exist or not.
		Boolean JiraIssueExist = CheckJiraissueExist(BugSummary);
		if (JiraIssueExist == false) {
			// If the Jira Issue donot exist in the Project Proceed with
			// creating New ticket
			String data = "{\"fields\": {\"project\":{\"key\": \"STOM\"},\"summary\":\""
					+ BugSummary
					+ "\",\"description\":\""
					+ Description
					+ " \",\"issuetype\": {\"name\":\"Bug\"},"
					+ "\"assignee\":{\"name\":\""+ Uname +"\"}}}";
			// Setting the Header and authentication. Can be generalized later.
			System.out.println(data);
			String auth = GetTokenRequest();
			WebResource webResource = client1.resource(CreateissueURL);
			ClientResponse response = webResource
					.header("Authorization", "Basic " + auth)
					.type("application/json").accept("application/json")
					.post(ClientResponse.class, data);
			int statusCode = response.getStatus();
			String Keyofissue = response.toString();
			// client.destroy();
			if (statusCode == 401) {
				throw new AuthenticationException(
						"Invalid Username or Password");
			} else if (statusCode == 403) {
				throw new AuthenticationException("Forbidden");
			} else if (statusCode == 200 || statusCode == 201) {
				System.out.println("Ticket Create succesfully");
			}
			// A New Successful code is added in JIRA as "201 " and same is
			// captured and handled.
			else if (statusCode == 201) {
				System.out
						.println("Ticket Created succesfully with some JIRA specific issue");
			} else {
				System.out.print("Http Error : " + statusCode);
			}
			// ******************************Getting Response body
			// **************************
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(response.getEntityInputStream()));
			String line = null;
			while ((line = inputStream.readLine()) != null) {
				System.out.println("Bug Created in Jira and details are ::  "
						+ line);
				//ExtentCucumberFormatter.setTestRunnerOutput("Bug Created in Jira and details are ::  "+ line);
				// Ticket created and fetching the issue number from the
				// response
				String Checktheissueconversion = line;
				// Below Piece of code will fetch the Key from
				String CompleteResponseofNewIssueticket = Checktheissueconversion;
				Pattern CheckNewissuePattern = Pattern
						.compile("key\":\"(.*?)\",\"self");
				Matcher Newissuwmatcher = CheckNewissuePattern
						.matcher(CompleteResponseofNewIssueticket);
				if (Newissuwmatcher.find()) {

					String NewIssueKey = Newissuwmatcher.group(1);
					System.out
							.println("newly created issue ticket number is:: "
									+ NewIssueKey);
					//ExtentCucumberFormatter.setTestRunnerOutput("newly created issue ticket number is:: "+ NewIssueKey);

					URL url = new URL(SearchTestcaseURL + LabelNameofTestcase);
					String authEncoded = GetTokenRequest();
					HttpURLConnection connection = (HttpURLConnection) url
							.openConnection();
					connection.setRequestMethod("GET");
					connection.setDoOutput(true);
					connection.setRequestProperty("Authorization", "Basic "
							+ authEncoded);
					BufferedReader inputStream1 = new BufferedReader(
							new InputStreamReader(connection.getInputStream()));
					String CompleteresponseofLabelSearch = null;
					while ((CompleteresponseofLabelSearch = inputStream1
							.readLine()) != null) {
						String Checktheissueconversion1 = CompleteresponseofLabelSearch;
						// Below Piece of code will fetch the Key from
						String TaskKeyresponse = CompleteresponseofLabelSearch;
						// System.out.println(TaskKeyresponse);
						Pattern PatternTaskkey = Pattern
								.compile("key\":\"(.*?)\",\"fields");
						Matcher MatcherTaskkey = PatternTaskkey
								.matcher(TaskKeyresponse);
						if (MatcherTaskkey.find()) {
							String NewTaskkey = MatcherTaskkey.group(1);
							System.out
									.println("The Testcase Key Successfully fetched from the scenario label is ::  "
											+ NewTaskkey);

							// Below method will link the New Bug with the
							// Failed Test case
							LinkDefect(NewTaskkey, NewIssueKey);

							System.out
									.println("Defects linked Successfully to the Test cases :: "
											+ NewTaskkey + " " + NewIssueKey);
							/*ExtentCucumberFormatter
									.setTestRunnerOutput("Defects linked Successfully to the Test cases :: "
											+ NewTaskkey + " " + NewIssueKey);*/

							// Below will upload the attachment to the Failed
							// defect
							boolean AttachmentUploadStatus = UploadAttachmenttotheIssue(
									NewIssueKey, ScreenshotPath);
							if (AttachmentUploadStatus == true) {
								System.out
										.println("Attachment uploaded successfully for the bug raised");
							} else {
								System.out
										.println("Attachment Not uploaded. Please upload attachment to bug manually , System facing some technical issue.");
							}

						}
					}

				}

			}

		} else {

			System.out
					.println("Already Similar Bug Exist in Jira. Please search for the bug with following summary in JIRA "
							+ "\"" + Summaryfrombug + " \"");

		}
	}

	// ***************************** Below Method pull all the issues from JIRA
	// and check the issue is already exist or NOT**********
	public static boolean CheckJiraissueExist(String Summaryfrombug)
			throws IOException {

		System.out.println("Method name :: CheckJiraissueExist::  "
				+ Summaryfrombug);

		URL url = new URL(SearchissueURL);
		String authEncoded = GetTokenRequest();
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", "Basic " + authEncoded);
		// Creating a File to fetch the content of all issues in JIRA and store
		// it for futher manipulation
		File file = new File("AllIssueContent.txt");
		InputStream in = (InputStream) connection.getInputStream();
		OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
		for (int b; (b = in.read()) != -1;) {
			out.write(b);
		}
		boolean returnstatusexist;
		// Read and store the text contents into a String variable
		String issuecontent = readFile("AllIssueContent.txt");
		if (issuecontent.contains(Summaryfrombug)) {
			returnstatusexist = true;
		} else {
			returnstatusexist = false;
		}
		out.close();
		in.close();
		// Delete the temporary file created .Comment below line if you need the
		// file to debug
		file.delete();
		return returnstatusexist;
	}

	/*
	 * Below Method will upload attachment after creation of issue Pending part
	 * is we need to fetch the right JIRA id after creation of JIRA ticket.
	 */

	public static boolean UploadAttachmenttotheIssue(String IssueKey,
			String AttachmentPath) throws IOException {

		System.out.println(" Upload attachment  :: " + " " + IssueKey
				+ "Attachmentpath :: " + AttachmentPath);

		String auth = GetTokenRequest();
		CloseableHttpClient httpclient = HttpClients.createDefault();
		// Issue id Hardcoded here. Please update it later accordingly
		HttpPost httppost = new HttpPost(UploadAttachmentURL + IssueKey
				+ "/attachments");
		httppost.setHeader("X-Atlassian-Token", "nocheck");
		httppost.setHeader("Authorization", "Basic " + auth);
		String Attachment = AttachmentPath.replace("\\", "\\\\");
		File fileToUpload = new File(AttachmentPath);
		// File fileToUpload = new File("D:\\footlocker.png");
		FileBody fileBody = new FileBody(fileToUpload);
		HttpEntity entity = MultipartEntityBuilder.create()
				.addPart("file", fileBody).build();
		httppost.setEntity(entity);
		String mess = "Executing Attachment request "
				+ httppost.getRequestLine();
		CloseableHttpResponse response;

		try {
			response = httpclient.execute(httppost);
		} finally {
			httpclient.close();
		}

		if (response.getStatusLine().getStatusCode() == 200) {
			System.out.println("Attachment Uploaded Succesfully");
		} else {
			// System.out.println("Noattachment");
		}
		return true;
	}

	// Below Method is return to read a text file and pass the value
	public static String readFile(String pathname) throws IOException {
		File file = new File(pathname);
		StringBuilder fileContents = new StringBuilder((int) file.length());
		Scanner scanner = new Scanner(file);
		String lineSeparator = System.getProperty("line.separator");

		try {
			while (scanner.hasNextLine()) {
				fileContents.append(scanner.nextLine() + lineSeparator);
			}
			return fileContents.toString();

		} finally {
			scanner.close();
		}
	}

	// Link Defect

	public static void LinkDefect(String TestCaseKey, String DefectKey)
			throws AuthenticationException, ClientHandlerException, IOException {

		System.out.println("Linkdefect  ::" + TestCaseKey + " " + DefectKey);
		Client client = Client.create();
		// Pass Project authentication details for making a successful
		// connnection to JIRA
		WebResource webResource = client.resource(LinkIssueURL);
		String data = "{\"type\": {\"name\": \"blocks\" }, \"inwardIssue\": {\"key\": \""
				+ DefectKey
				+ "\" },\"outwardIssue\": {\"key\": \""
				+ TestCaseKey
				+ "\" },\"comment\": { \"body\": \"Please check the linked test case"
				+ " "
				+ TestCaseKey
				+ "\", \"visibility\": { \"type\": \"group\", \"value\": \"\" }}}";

		String auth = GetTokenRequest();
		ClientResponse response = webResource
				.header("Authorization", "Basic " + auth)
				.type("application/json").accept("application/json")
				.post(ClientResponse.class, data);
		int statusCode = response.getStatus();
		client.destroy();
	}

	public static String GetTokenRequest() {
		String auth = new String(Base64.encode(Uname + ":" + Password));
		String GetToken = auth;
		return GetToken;
	}
}
