package com.tcs.saf.exceptions;

@SuppressWarnings("serial")
public class DataSheetException extends RuntimeException{
	
	public DataSheetException(String message)
	  {
	    super(message);
	  }

}
